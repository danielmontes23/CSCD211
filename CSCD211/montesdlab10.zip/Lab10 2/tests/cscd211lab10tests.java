import org.junit.jupiter.api.Test;

import static cscd211recursion.CSCD211Lab10.square;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class cscd211lab10tests {
    @Test
    public void squareTest(){
        assertEquals(3, square(2));
    }

    @Test
    public void negativeNumberSquareTest(){
        assertEquals(0, square(-3));
    }

    @Test
    public void zeroSquareTest(){
        assertEquals(0, square(0));
    }

    @Test
    public void twentySquareTest(){
        assertEquals(210, square(20));
    }

    @Test
    public void thirteenSquareTest(){
        assertEquals(91, square(13));
    }

    @Test
    public void oneSquareTest(){
        assertEquals(1, square(1));
    }

    @Test
    public void oneHundredsquareTest(){
        assertEquals(5050, square(100));
    }

    @Test
    public void thirtyEightSquareTest(){
        assertEquals(741, square(38));
    }

    @Test
    public void negativeThousandsquareTest(){
        assertEquals(0, square(-1000));
    }

    @Test
    public void fourtyTwoSquareTest(){
        assertEquals(903, square(42));
    }

}
