package cscd211linkedlist;

import java.util.NoSuchElementException;

public class LinkedList<T extends Comparable<? super T>> {

    private class Node{

        public T data;

        public Node next;
        //public LinkedList<T>.Node next;

        public Node(final T data) {
            this.data = data;
            //this.next = null;
        }

        //private Node head;

        //private int size;

        public Node(final T data, final Node next){
            this.data = data;
            this.next = next;
        }
    }

        private Node head;

        private int size;


        public LinkedList() {
            this.head = new Node(null);
            this.size = 0;
        }

        public int size() {
            return this.size;
        }

        public void clear() {
            this.head = new Node(null, null);
            this.size = 0;
        }

        public void addFirst(final T item) {
            if (item == null)
                throw new IllegalArgumentException("Item is null");

            Node nn = new Node(item, null);
            nn.next = this.head.next;
            this.head.next = nn;
            // this.head.next = new Node(data, this.head.next);
            this.size++;
        }

        public int indexOf(final T item) {
            if (item == null)
                throw new IllegalArgumentException("Item is null");

            int index = 0;
            Node cur = this.head.next;

            while(cur != null){
                if(cur.data.equals(item))
                    return index;

                index++;
                cur = cur.next;
            }
            //if(index == this.size)
                return -1;

            //return index;
        }

        public T removeFirst() {
            if(this.size == 0) {
                throw new NoSuchElementException("Empty List");
            }
            T data = this.head.data;
            this.head = this.head.next;
            this.size--;
            return data;
        }

        public T removeLast() {
            if(this.size == 0)
                throw new NoSuchElementException("Empty List");

            if(this.size == 1)
                return this.removeFirst();

            Node cur = this.head, prev = null;
            while (cur.next != null) {
                prev = cur;
                cur = cur.next;
            }
            prev.next = cur.next;
            this.size--;
            return (T)cur.data;
        }

        public T remove(final int index) {
            if (index < 0 || index >= size())
                throw new IndexOutOfBoundsException("Out of bounds.");

            if (this.head == null) {
                return null;
            }
            Node cur = this.head, prev = null;
            int count = 0;
            if (index == 0) {
                T data = this.head.data;
                this.head = this.head.next;
                size--;
                return data;
            }
            while (cur != null && count != index) {
                prev = cur;
                cur = cur.next;
                count++;
            }
            Node nn = new Node(cur.data, cur.next);
            prev.next = cur.next;
            size--;

            return cur.data;

//            if (index == 0) {
//                this.removeFirst();
//                Node cur = this.head.next;
//                this.head = this.head.next;
//                cur.next = null;
//                this.size--;
//                return (T) (cur.data);
//            }
//
//            int location = 1;
//            Node cur = this.head.next;
//            Node prev = this.head;
//            for (; location != index; location++) {
//                prev = cur;
//                cur = cur.next;
//            }
//
//            prev.next = cur.next;
//            cur.next = null;
//            this.size--;
//            return (T) (cur.data);
//        }
        }

        public void add(final int index, final T item) {
            if (index < 0 || index > this.size())
                throw new IndexOutOfBoundsException("Out of bounds.");
            if (item == null)
                throw new IllegalArgumentException("Item is null");

            Node nn = new Node(item, null);
            Node cur = this.head.next, prev = this.head;

            if (cur.next == null)
                this.head.next = new Node(item, this.head.next);
            else {
                for (; cur.next != null && cur.data.compareTo(nn.data) < 0; cur = cur.next)
                    prev = cur;
            }
            nn.next = cur;
            prev.next = nn;
            this.size++;
        }

        public boolean removeLastOccurrence(final T item) {
            if (item == null)
                throw new IllegalArgumentException("Item is null");

            if ( this.size ==0)
                return false;
            int index =-1;
            int x =0;
            Node cur = this.head.next;

            while ( cur !=null){
                if (cur.data.equals(item))
                    index =x;
                x++;
                cur = cur.next;
            }
            if ( index == -1)
                return false;

            this.remove(index);
            return true;
        }

        public boolean removeFirstOccurrence(final T item) {
            if (item == null)
                throw new IllegalArgumentException("Item is null");

            if( this.size ==0)
                return false;

            Node cur= this.head.next;
            Node prev = this.head;

            while (cur !=null) {
                if (cur.data.equals(item)) {
                    prev.next  = cur.next;
                    cur.next = null;
                    this.size--;
                    return true;
                }
                prev = cur;
                cur = cur.next;
            }
            return true;
        }

        public void addLast(final T item) {
            if (item == null)
                throw new IllegalArgumentException("Item is null");


            Node nn = new Node(item, null);
            if(this.head == null){
                this.head = nn;
            } else {
                Node cur = this.head;
                while (cur.next != null) {
                    cur = cur.next;
                }
                cur.next = nn;
            }
            this.size++;

            //Node cur = this.head;
            //for(; cur.next != null; cur = cur.next);
            //cur.next = nn;
            //this.size++;
        }

        public String toString() {
            if (this.size == 0)
                return "Empty List";

            String str = "";
            Node cur = this.head;
            while (cur != null) {
                if (cur.next == null)
                    str += cur.data;
                else {
                    str += cur.data + ", ";
                }
                cur = cur.next;
            }
            return "["+ str + "]";
        }
//        }
//            Node cur = this.head;
//            String str = "[";
//
//            if (cur == null) {
//                return "Empty List";
//            }
//            while (cur.next != null) {
//                str += ", ";
//
//                cur = cur.next;
//            }
//            return str + "]";
//        }// toString

        public boolean contains(final T item) {
            if (item == null)
                throw new IllegalArgumentException("Item is null");

            if (size == 0)
                return false;
            //int counter = 0;
            //Node cur = this.head;

            //if (!(indexOf(item) == -1))
                //return true;

            return indexOf(item) != -1;
        }
    }


