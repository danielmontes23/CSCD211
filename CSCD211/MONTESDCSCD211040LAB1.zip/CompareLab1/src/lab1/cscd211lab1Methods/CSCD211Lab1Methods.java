package lab1.cscd211lab1Methods;

import lab1.cscd211classes.Players;

import java.io.PrintStream;
import java.io.StringBufferInputStream;
import java.lang.reflect.Array;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
/**
 * The class contains a set of methods required for the lab to work properly
 *
 * @NOTE All parameters passed to method must be passed as final.  You don't need to write a default value constructor
 * since we don't have any class level variable.
 */
public class CSCD211Lab1Methods {
    /**
     * The fillArray method first creates an array of players, and then fills each index of the player array with
     * a new player object.
     *
     * @param fin Representing the Scanner object to the file
     * @param total Representing the total number of elements to be contained in the array
     * @return Player [] Representing array filled with Player objects
     *
     * @throws IllegalArgumentException if fin is null
     * @throws IllegalArgumentException if total is < 1
     *
     * @NOTE The file contents are comma separated values in the order title, isbn, pages, authors
     */
    public static Players[] fillArray(final Scanner fin,final int total) throws ParseException {
        //throw new UnsupportedOperationException("Method not implemented");
        if(fin == null)
            throw new IllegalArgumentException("Fin is null");
        if(total < 1)
            throw new IllegalArgumentException("Total is less than 1");

        Players[] playersArray = new Players[total];

        for(int i = 0; i< total; i++){
            String line = fin.nextLine();

            String[] info = line.split(",");
            String playerID = info[0].trim();
            int birthyear = Integer.parseInt(info[1]);
            int birthMonth = Integer.parseInt(info[2]);
            int birthDay = Integer.parseInt(info[3]);
            String birthCountry = info[4].trim();
            String birthState = info[5].trim();
            String birthCity = info[6].trim();
            String firstName = info[7].trim();
            String lastName = info[8].trim();
            String nameGiven = info[9].trim();
            int weight = Integer.parseInt(info[10]);
            int height = Integer.parseInt(info[11]);
            char bats = info[12].trim().charAt(0);
            char throwsHand = info[13].trim().charAt(0);

            DateFormat form = new SimpleDateFormat("MM/dd/yyyy");
            Date debut = form.parse(info[14]);
            Date finalGame = form.parse(info[15]);

            String retroID = info[16].trim();
            String bbrefID = info[17].trim();

            playersArray[i] = new Players(playerID, birthyear, birthMonth, birthDay, birthCountry, birthState, birthCity, firstName, lastName, nameGiven, weight, height, bats, throwsHand, debut, finalGame, retroID, bbrefID);
        }

        return playersArray ;
    }//end fillArray

    /**
     * The menu method offers the user a choice from:<br>
     * 1) Print the players to the screen<br>
     * 2) Print the players to a file<br>
     * 3) Sort the players based on natural order<br>
     * 4) Sort the players based on total order<br>
     * 5) Add a new player to the players<br>
     * 6) Search the players for a player<br>
     * 7) Quit<br>
     *
     * @param kb Representing the Scanner object to the keyboard
     * @return int Representing the menu choice which is ensured by you
     * to be between 1 and 7 inclusive
     *
     * @throws IllegalArgumentException if kb is null
     *
     * @NOTE You must ensure the input buffer is empty at the end of the method
     */
    public static int menu(final Scanner kb)
    {
        if(kb == null)
            throw new IllegalArgumentException("bad scanner menu");

        int choice;
        do
        {
            System.out.println("Please choose from the following");
            System.out.println("1) Print the players to the screen");
            System.out.println("2) Print the players to a file");
            System.out.println("3) Sort the players based on natural order");
            System.out.println("4) Sort the players based on total order");
            System.out.println("5) Add a new player to the players");
            System.out.println("6) Search the players for a player");
            System.out.println("7) Quit");
            System.out.print("Choice --> ");
            choice = Integer.parseInt(kb.nextLine());
            System.out.println();
        }while(choice < 1 || choice > 7);

        return choice;
    }// end menu

    /**
     * The printplayers calls the toString method of players and prints each player out followed by a CR
     *
     * @param myPlayers Representing the array of players
     * @param out Representing the PrintStream object to the screen or the file
     *
     * @throws IllegalArgumentException if array is null or the length is &lt; 1
     * @throws IllegalArgumentException if output stream is null
     */
    public static void printPlayers(Players[] myPlayers, PrintStream out) {
        //throw new UnsupportedOperationException("Method not implemented");
        if(myPlayers == null || myPlayers.length < 1)
            throw new IllegalArgumentException("Bad parameters");
        if(out == null)
            throw new IllegalArgumentException("Output stream is null");

        for(int i = 0;i < myPlayers.length; i++) {
            System.out.print(myPlayers[i]);
        }
    }//end printPlayers

    /**
     * The readOutputFilename calls the readString to read a output filename
     *
     * @param kb Representing the Scanner object to the keyboard
     * @return String Representing the output filename
     *
     * @throws IllegalArgumentException if kb is null
     *
     * @NOTE You must ensure the input buffer is empty at the end of the method
     */
    public static String readOutputFilename(final Scanner kb) {
        if(kb == null)
            throw new IllegalArgumentException("Bad param readOutputFilename");

        return readString("output filename",kb);
    }
    /**
     * The addPlayer method makes a new array of the old size plus one<br>
     * Next it copies the players from the old array to the new array<br>
     * Next it adds the new player in last index of the new array
     *
     * @param players Representing the old array to be copied
     * @param aPlayer Representing the player to add to the array
     * @return Players [] Representing the new array with the old players copied over
     * and the new player in the last index of the new array.
     *
     * @throws IllegalArgumentException if array is null or length < 1
     * @throws IllegalArgumentException if aPlayer is null
     *
     * @NOTE You must ensure the input buffer is empty at the end of the method
     */
    public static Players[] addPlayer(Players[] players, final Players aPlayer) {
        //throw new UnsupportedOperationException("Method not implemented");
        if(players == null || players.length < 1)
            throw new IllegalArgumentException("Bad parameters");
        if(aPlayer == null)
            throw new IllegalArgumentException("Player is null");
    //Method 1

        Players[] newArray = new Players[players.length + 1];

        for(int i = 0; i < players.length; i++){
            newArray[i] = players[i];
        }

        newArray[players.length] = aPlayer;

        return newArray;

    }//end addPlayer
    /**
     * The createPlayer method prompts the user to enter information to create a new player
     * Entering the information is done by the private method readString.
     *
     * @param kb Representing the Scanner object to the keyboard
     * @return Players Representing a new player object
     *
     * @throws IllegalArgumentException if kb is null
     * @throws ParseException if the date cannot be parsed correctly
     * @NOTE You must ensure the input buffer is empty at the end of the method
     */
    public static Players createPlayer(final Scanner kb) throws ParseException {
        //throw new UnsupportedOperationException("Method not implemented");
        if(kb == null) {
            throw new IllegalArgumentException("Kb is null");
        }

        System.out.println("Enter player ID: ");
        String playerID = kb.nextLine();

        System.out.println("Enter a birth year: ");
        int birthyear = kb.nextInt();
        System.out.println("Enter a birth month: ");
        int birthMonth = kb.nextInt();
        System.out.println("Enter a birth day: ");
        int birthDay = kb.nextInt();

        kb.nextLine();

        System.out.println("Enter in a birth country: ");
        String birthCountry = kb.nextLine();
        System.out.println("Enter in a birth state: ");
        String birthState = kb.nextLine();
        System.out.println("Enter in a birth city: ");
        String birthCity = kb.nextLine();

        System.out.println("Enter in a first name: ");
        String firstName = kb.nextLine();
        System.out.println("Enter in a last name: ");
        String lastName = kb.nextLine();
        System.out.println("Enter in a given name: ");
        String nameGiven = kb.nextLine();

        System.out.println("Enter a weight: ");
        int weight = kb.nextInt();

        System.out.println("Enter a height: ");
        int height = kb.nextInt();

        kb.nextLine();

        System.out.println("Enter the bat: ");
        String bat = kb.nextLine();
        char bats = bat.charAt(0);

        System.out.println("Enter the players throwing hand: ");
        String hand = kb.nextLine();
        char throwsHand = hand.trim().charAt(0);

        System.out.println("Enter the debut game date MM/DD/YYYY: ");
        String debut = kb.nextLine();
        DateFormat form = new SimpleDateFormat("MM/dd/yyyy: ");
        Date debut1 = form.parse(debut);

        System.out.println("Enter the final game date MM/DD/YYYY: ");
        String date = kb.nextLine();
        Date finalGame = form.parse(date);

        System.out.println("Enter in the retro ID: ");
        String retroID = kb.nextLine();

        System.out.println("Enter in the bbref ID: ");
        String bbrefID = kb.nextLine();

        Players list = new Players(playerID, birthyear, birthMonth, birthDay, birthCountry, birthState, birthCity, firstName, lastName, nameGiven, weight, height, bats, throwsHand, debut1, finalGame, retroID, bbrefID);
        return list;
        //return new Players(playerID, birthyear, birthMonth, birthDay, birthCountry, birthState, birthCity, firstName, lastName, nameGiven, weight, height, bats, throwsHand, debut, finalGame, retroID, bbrefID);
    }//end createPlayer

    /**
     * The readString reads a string from the keyboard and ensures the string is not null or empty
     *
     * @param type Representing a String for the prompt on what to enter
     * @param kb Representing the Scanner object to the keyboard
     * @return String Representing the appropriate String
     *
     * @throws IllegalArgumentException if kb is null
     *
     * @NOTE You must ensure the input buffer is empty at the end of the method
     */
    private static String readString(final String type, final Scanner kb)
    {
        if(type == null || type.isEmpty() || kb == null)
            throw new IllegalArgumentException("Bad param readString");

        String str="";
        do
        {
            System.out.print("Please enter the " + type + " ");
            str = kb.nextLine().trim();
        }while(str == null || str.isEmpty());

        return str;
    }// end readString
}//end class
