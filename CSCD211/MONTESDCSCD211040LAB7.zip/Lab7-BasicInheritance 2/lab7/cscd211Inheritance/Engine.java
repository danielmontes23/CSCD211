package lab7.cscd211Inheritance;

public class Engine implements Comparable<Engine>
{
    protected int horsePower;
    private String manufacturer;

    public Engine(final String manufacturer, final int horsePower){
        if(manufacturer == null || manufacturer.isBlank() || horsePower <= 0)
            throw new IllegalArgumentException("Bad Parameters.");

        this.manufacturer = manufacturer;
        this.horsePower = horsePower;
    }

    public Engine(final int horsePower, final String manufacturer){
        this(manufacturer, horsePower);
    }

    public String toString(){
        return "Manufacturer: " + manufacturer + " with HP of " + horsePower + ".";
    }

    public int calcOutput(){
        return horsePower / 5;
    }

    public String getManufacturer(){
        return this.manufacturer;
    }

    public int compareTo(Engine pi){
        int res = this.horsePower - pi.horsePower; // if equal == 0
        if (res != 0)
            return res;

        res = this.manufacturer.compareTo(pi.manufacturer);
        return res;
    }
}

