package lab7.cscd211Inheritance;

public class CarEngine extends Engine
{

    public CarEngine(final String manufacturer, final int horsePower){
        super(manufacturer, horsePower);
    }

    public CarEngine(final int horsePower, final String manufacturer){
        super(horsePower, manufacturer);
    }

    @Override
    public String toString(){
        return "Car Engine - Manufacturer: " + getManufacturer() + " with HP of " + horsePower + ".";
    }

    @Override
    public int calcOutput(){
        return super.calcOutput() / 12;
    }
}
