package lab7.cscd211Inheritance;

public class TruckEngine extends Engine
{
    private Boolean diesel;

    public TruckEngine(final String manufacturer, final int horsePower, final boolean diesel){
        super(manufacturer, horsePower);
        this.diesel = diesel;
    }

    @Override
    public String toString(){
        if(diesel){
            return "Truck Engine - Manufacturer: " + getManufacturer() + " with HP of " + horsePower + " is a diesel engine.";
        }
        else {
            return "Truck Engine - Manufacturer: " + getManufacturer() + " with HP of " + horsePower + " is NOT a diesel engine.";
        }
    }

    @Override
    public int calcOutput(){
        int output = super.calcOutput();
        if(diesel){
            output = (output / 10);
            return output;
        }
        else{
            output = (output / 8);
        }
        return output;
    }
}
