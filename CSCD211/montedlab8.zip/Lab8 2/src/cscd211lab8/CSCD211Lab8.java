package cscd211lab8;

import java.io.*;
import java.util.*;
import cscd211utils.*;
import cscd211package.type.*;
import cscd211package.vehicle.*;

public class CSCD211Lab8
{
	public static void main(String [] args)
	{
      int maxPackages = 0;
      String driverName = "";
      
      File inf = FileUtils.openInputFile("manifest.txt");
      Scanner fin = FileUtils.openScanner(inf);

          PrintStream fout = null;
          try {
                fout = new PrintStream(new FileOutputStream("log.txt"), true);
          } catch (FileNotFoundException e) {
                throw new RuntimeException(e);
          }

          driverName = fin.nextLine();
      maxPackages = Integer.parseInt(fin.nextLine());
      
      Truck theTruck = new Truck(driverName, maxPackages);
      theTruck.load(fin, fout);
      theTruck.drive(fout);
      theTruck.unload(fout);
      fin.close();
      fout.close();
      
   }//end main

}//end class