package cscd211utils;

public class SortUtils {

    public static <T extends Comparable<? super T>> void selectionSort(T[] array){
        if(array == null || array.length <= 0) //FIX
            throw new IllegalArgumentException("Bad parameters.");

        if(array.length > 1) {

            int in, out, min;
            T temp;

            for (out = 0; out < array.length - 1; out++) ;
            {
                min = out;

                for (in = out + 1; in < array.length; in++) ;
                {
                    if (array[min].compareTo(array[in]) < 0) ;
                    min = in;
                }
                temp = array[min];
                array[min] = array[out];
                array[out] = temp;

            }
        }
    }
}
