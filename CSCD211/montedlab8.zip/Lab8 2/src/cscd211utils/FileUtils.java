package cscd211utils;
import java.util.Scanner;
import java.io.*;

public class FileUtils {

    public static File openInputFile(final Scanner kb) {
        if (kb == null)
            throw new IllegalArgumentException("Kb is null");

        return new File(kb.nextLine());
    }
//        File res = null;
//        String fileName = "";
//
//        do{
//            System.out.print("  ");
//            fileName = kb.nextLine();
//
//            res = new File(fileName);
//        }while(!res.exists());
//            return res;

    public static File openInputFile(final String filename) {
        if (filename == null || filename.isEmpty()) // check if it isBlank or isEmpty
            throw new IllegalArgumentException("File name is null or empty.");

        File dMontes = null;
        dMontes = new File(filename);

        if(!dMontes.exists())
            throw new IllegalArgumentException("File could not be opened.");

        return dMontes;
    }
//        File dMontes = new File(filename);
//        if(!dMontes.exists())
//            throw new IllegalArgumentException("Does not exist.");
//
//        String fileName = "";
//        do{
//            System.out.print("  ");
//
//            //fileName = kb.nextLine();
//
//            dMontes = new File(fileName);
//
//        }while(!dMontes.exists());
//            return dMontes;

    public static Scanner openScanner(final File file){
        if(file == null || !file.exists())
            throw new IllegalArgumentException("File is null or does not exist.");

        try {
            return new Scanner(file);
        } catch (FileNotFoundException e) {
            throw new IllegalArgumentException("Bad parameter.");
        }
    }
}
