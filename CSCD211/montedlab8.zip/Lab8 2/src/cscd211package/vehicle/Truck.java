package cscd211package.vehicle;

import cscd211package.type.Package;
import  cscd211package.type.Box;
import cscd211package.type.Crate;
import cscd211package.type.Letter;
import cscd211package.type.MetalCrate;
import cscd211package.type.WoodCrate;
import cscd211lab8exceptions.UnknownPackage;
import java.util.Scanner;
import java.io.*;

public class Truck extends Object{

    private String driver;
    private int load;
    private int maxPackages;
    private Package[] thePackages;

    public Truck(final String driver, final int maxPackages){
        this.driver = driver;
        this.maxPackages = maxPackages;
        thePackages = new Package[this.maxPackages];
    }

    public int getMaxPackages(){
        return maxPackages;
    }

    public String getDriver(){
        return this.driver;
    }

    public int getLoad(){
        return this.load;
    }

    public Package[] getThePackages(){
        //if(fin == null || fout == null)
            throw new IllegalArgumentException("Bad parameters.");

    }

    public void load(final Scanner fin,  final PrintStream fout){
        if(fin == null || fout == null)
            throw new IllegalArgumentException("Bad parameters.");

        fout.print("Driver name: " + this.getDriver() + "\n" + "Maximum packages truck can carry " + this.getMaxPackages() + "\n\n" + "PACKAGE LEASING INFORMATION:\n"); //Print statement is on the video Stu posted
//        while(fin.hasNext()){
//            try{
//                String[] = this.grabPackageInfo(fin); //Reads in the tracking number
//                Package new  = this.getPackage();
//                attemptToLoad(fout, new Pack);
//            }
//            catch(){
//
//            }
            //String[] = this.grabPackageInfo(fin); //Reads in the tracking number

        //}
    }

    public String[] grabPackageInfo(final Scanner fin){
        if(fin == null)
            throw new IllegalArgumentException("Bad parameters.");

        int number;
        String str = "";

        number = Integer.parseInt(fin.nextLine());

        String [] array;
        if (number % 10 == 0)
        { array = new String[4];}
        else if (number % 10 == 1)
        { array = new String[5];}
        else
        { array = new String[6];}
        array[0] = number + "";
        for ( int i = 1; i < array.length; i++)
        {
            array[i] = fin.nextLine();
        }
        return array;
    }

    public Package getPackage(final String[] packageInfo) throws UnknownPackage {
        if(packageInfo == null)
            throw new IllegalArgumentException("Null.");
        //if(packageInfo < 4)
            //throw new IllegalArgumentException("Package info is less than 4.");
        return null;
    }

    public void attemptToLoad(final PrintStream fout, final Package temp){
        if(fout == null || temp == null)
            throw new IllegalArgumentException("Bad parameters.");

        //if
    }

    public void drive(final PrintStream fout){
        if(fout == null)
            throw new IllegalArgumentException("Fout is null.");


    }

    public void unload(final PrintStream fout) {
        if (fout == null)
            throw new IllegalArgumentException("Bad parameters.");
        if (this.load == 0)
            throw new IllegalArgumentException("Truck is empty. Nothing to unload.");

    }

    public void loadPackage(final Package toAdd, final int index){
        if(toAdd == null) // fix this line of code
            throw new IllegalArgumentException("Bad parameters.");


    }

    public void printToLog(final PrintStream fout, final String str){
        //if statement
        if(fout == null || str == null)
            throw new IllegalArgumentException("Null parameters.");
        if(str.isEmpty())
            throw new IllegalArgumentException("Str is blank.");

        fout.println(str);
    }
}
