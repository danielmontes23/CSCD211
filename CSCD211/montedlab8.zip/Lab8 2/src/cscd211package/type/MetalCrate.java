package cscd211package.type;

public class MetalCrate extends Crate{

    protected static int MAX_HEIGHT = 60;
    protected static int MAX_LENGTH = 60;
    protected static int MAX_WEIGHT = 500;
    protected static int MAX_WIDTH = 60;

    public MetalCrate(final int trackNum, final int weight, final int length, final int width, final int height, final String contents){
        super(trackNum, weight, length, width, height, contents);
        if( weight > MAX_WEIGHT)
            setTooBig(true);
        if( length > MAX_LENGTH)
            setTooBig(true);
        if( width > MAX_WIDTH)
            setTooBig(true);
        if( height > MAX_HEIGHT)
            setTooBig(true);
        //this.trackNum = trackNum;
        //this.weight = weight;
        //this.length = length;
        //this.width = width;
        //this.height = height;
    }
}
