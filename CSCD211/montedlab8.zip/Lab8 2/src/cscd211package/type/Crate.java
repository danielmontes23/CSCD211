package cscd211package.type;


public abstract class Crate extends Package{

    protected String contents;
    private int height;

    protected Crate(final int trackNum, final int weight, final int length, final int width, final int height, final String contents){
        super(trackNum, weight, length, width);
        if(height < 1)
            throw new IllegalArgumentException("Bad params Crate constructor");
        if(contents == null || contents.isBlank())
            throw new IllegalArgumentException("Null or empty contents.");
        //if statement for the if(contents == fragile)

        //this.trackNum = trackNum;
        //this.weight = weight;
        //this.length = length;
        //this.width = width;
        this.height = height;
        this.contents = contents;
        //super(trackNum, weight, length, width, height);
    }


    public int getHeight(){
        return this.height;
    }

    public String getContents(){
        return this.contents;
    }

    public String toString(){
        String str = "";
        return str = "Length: " + getLength() + " inches " + "Width: " + getWidth() + " inches" + " Contents: " + contents;

        //Length: "length" inches Width: "width" inches Height: "height" inches Contents: "contents"
    }
}
