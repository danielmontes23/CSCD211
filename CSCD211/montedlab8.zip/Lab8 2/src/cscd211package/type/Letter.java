package cscd211package.type;

public class Letter extends Package{

    protected static final int MAX_LENGTH = 18;
    protected static final int MAX_WEIGHT = 24;
    protected static final int MAX_WIDTH = 18;

    public Letter(final int trackNum, final int weight, final int length, final int width){
        super(trackNum, weight, length, width);

        if( weight > MAX_WEIGHT)
            setTooBig(true);
        if( length > MAX_LENGTH)
            setTooBig(true);
        if( width > MAX_WIDTH)
            setTooBig(true);
    }

    @Override
    public String toString(){
        String str = "";
        return str = "Length: " + getLength() + " inches " + "Width: " + getWidth() + " inches";

        //Length: "length" inches Width: "width" inches
    }
}
