package cscd211package.type;

public class WoodCrate extends Crate{

    protected static final int MAX_HEIGHT = 48;

    protected static final int MAX_LENGTH = 48;

    protected static final int MAX_WEIGHT = 200;

    protected static final int MAX_WIDTH = 48;

    public WoodCrate(final int trackNum, final int weight, final int length, final int width, final int height, final String contents){
        super(trackNum, weight, length, width, height, contents);
    }
}
