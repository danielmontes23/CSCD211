package cscd211package.type;

public class Box extends Package{

    private int height;
    protected static final int MAX_HEIGHT = 36;
    protected static final int MAX_LENGTH = 36;
    protected static final int MAX_WEIGHT = 100;
    protected static final int MAX_WIDTH = 36;

    public Box(final int trackNum, final int weight, final int length, final int width, final int height){
        super(trackNum, weight, length, width);
        if(height < 1)
            throw new IllegalArgumentException("Bad params Box constructor");

        if( weight > MAX_WEIGHT)
            setTooBig(true);
        if( length > MAX_LENGTH)
            setTooBig(true);
        if( width > MAX_WIDTH)
            setTooBig(true);
        if( height > MAX_HEIGHT)
            setTooBig(true);
        //this.trackNum = trackNum;
        //this.weight = weight;
        //this.length = length;
        //this.width = width;
        this.height = height;
    }

    public int getHeight(){
        return this.height;
    }

    public String toString(){
        String str = "";
        return str = "Package: " + "Length: " + getLength() + " inches " + "Width: " + getWidth() + " inches";
        //Length: "length" inches Width: "width" inches Height: "height" inch
    }
}
