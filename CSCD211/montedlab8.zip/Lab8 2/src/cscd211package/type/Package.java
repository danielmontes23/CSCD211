package cscd211package.type;

public abstract class Package implements Comparable<Package> {

    protected int length;
    private boolean tooBig;

    protected int trackNum;

    protected int weight;

    protected int width;

    protected Package(final int trackNum, final int weight, final int length, final int width){
        if(trackNum < 1 || weight < 1 || length < 1 || width < 1)
            throw new IllegalArgumentException("Bad params Package constructor");

        this.trackNum = trackNum;
        this.weight = weight;
        this.length = length;
        this.width = width;
    }

    public void setTooBig(final boolean tooBig){
        this.tooBig = tooBig;
    }

    public String getType(){
        return this.getType();
    }

    public int getWeight(){
        return this.weight;
    }

    public int getTrackNum(){
        return this.trackNum;
    }

    public boolean getTooBig(){
        return tooBig;
    }

    public String toString(){
        String str ="";

        //return str = "Lawyer: " + this.get();
        //Package Type: "type" Tracking Number: "trackNum" Weight: "weight"

        return str = "Package Type: " + getType() + " Tracking Number: " + trackNum + " Weight: " + getWeight();
    }

    public int compareTo(final Package pi) {
        if (pi == null)
            throw new IllegalArgumentException("PI is null.");

        int result = getType().compareTo(pi.getType());
        //int result = this.Package.compareTo(pi.Package);
        if (result != 0)
            return result;


        result = weight - pi.weight;
        return result;
    }

    public int getWidth(){
        return this.width;
    }

    public int getLength(){
        return this.length;
    }
}
