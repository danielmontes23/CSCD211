package cscd211lab8exceptions;

public class UnknownPackage extends Exception{

    public UnknownPackage(final String message){
        super(message);

        if(message == null || message.isBlank())
            throw new IllegalArgumentException("Bad params UnknownPackage constructor");
    }
}
