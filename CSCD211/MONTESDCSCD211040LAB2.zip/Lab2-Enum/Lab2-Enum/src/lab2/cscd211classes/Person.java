package lab2.cscd211classes;

import lab2.cscd211enums.Color;

public class Person implements Comparable<Person>{
    private final Color color;
    private final String fn;
    private final String ln;

    public Person(final String fn, final String ln, final Color color){
        if(fn == null || ln == null | color == null)
            throw new IllegalArgumentException("Bad Parameters.");

        this.fn = fn;
        this.ln = ln;
        this.color = color;
    }

    public int compareTo(final Person another){
        if(another == null)
            throw new IllegalArgumentException("Bad parameters.");

        if(this.ln.compareTo(another.ln) == 0) {
            if (this.fn.compareTo(another.fn) == 0) {
                return this.color.compareTo(another.color);
            }
        }
        return this.ln.compareTo(another.ln);
    }

    public Color getColor(){
        return this.color;
    }

    public String toString(){
        return this.fn + " " + this.ln + ", " + this.color + " ";
    }
}
