package lab2.cscd211enums;

import java.io.Serializable;

public enum Color implements Comparable<Color>, Serializable {

    blue,
    green,
    purple,
    red,

}


//    public static Color[] values() {
//        for (Color c : Color.values())
//            System.out.println(c);
//
//    }

//    public static Color valueOf(String name){
//
//    }
//}
