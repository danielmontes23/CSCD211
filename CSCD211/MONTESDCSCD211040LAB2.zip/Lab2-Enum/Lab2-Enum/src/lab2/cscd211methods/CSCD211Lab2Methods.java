package lab2.cscd211methods;

import lab2.cscd211classes.Person;
import lab2.cscd211enums.Color;

import java.util.Scanner;

public class CSCD211Lab2Methods {

    public static Color convertColor(final String color){
        if(color == null)
            throw new IllegalArgumentException("Bad parameter.");

        return Color.valueOf(color);
    }

    public static void displayAll(final Color toFind, final Person[] myPeeps){
        if(myPeeps == null)
            throw new IllegalArgumentException("Bad parameter.");

        for(int i = 0; i < myPeeps.length; i++){
            if(myPeeps[i].getColor() == toFind){
                System.out.println(myPeeps[i]);
            }
        }
    }

    public static Person[] fillArray(final Scanner fin, final int total){
        if(fin == null)
            throw new IllegalArgumentException("Bad parameter.");
        if(total <= 0)
            throw new IllegalArgumentException("Bad parameter.");

        Person[] newArray = new Person[total];

        for(int i = 0; i < newArray.length; i++){
            String firstName = fin.nextLine();
            String lastName = fin.nextLine();
            String color = fin.nextLine();

            Color Color1 = Color.valueOf(color);

            newArray[i] = new Person(firstName, lastName, Color1);
        }

        return newArray;
    }

    public static int menu(final Scanner kb){
        if(kb == null)
            throw new IllegalArgumentException("Bad scanner menu");

        int choice;
        do
        {
            System.out.println("Please choose from the following");
            System.out.println("1. Print the Array to the screen");
            System.out.println("2. Display all people that contain a certain color");
            System.out.println("3. Sort the array by Color");
            System.out.println("4. Sort the array by the 'natural order'");
            System.out.println("5. Quit");
            System.out.print("Choice --> ");
            choice = Integer.parseInt(kb.nextLine());
            System.out.println();
        }while(choice < 1 || choice > 5);

        return choice;
    }

    public static void printArray(final Person[] myPeeps){
        if(myPeeps == null)
            throw new IllegalArgumentException("Bad parameter.");

        for(int i = 0; i < myPeeps.length; i++){ //In case Person myPeep does not work
            System.out.print(myPeeps[i]);
        }

        //for (Person myPeep : myPeeps) { //To get rid of the warning for the code above
        //    System.out.print(myPeep);
        //}
    }

    public static Color readColor(final Scanner kb){
        if(kb == null)
            throw new IllegalArgumentException("Scanner is null.");

        System.out.println("Enter in a color: ");
        String color = kb.nextLine();

        return convertColor(color);
    }
}
