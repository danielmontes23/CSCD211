package cscd211tests;

import org.junit.jupiter.api.Test;
import cscd211LinkedList.*;

import java.util.NoSuchElementException;

import static org.junit.jupiter.api.Assertions.*;

class CSCD211LinkedListTest {

    @Test
    public void indexOfEmptyList() {
        LinkedList<String> list = new LinkedList<>();
        assertEquals(-1, list.indexOf("a"));
    }

    @Test
    public void itemNotInListIndexOfFilledList() {
        LinkedList<String> list = new LinkedList<>();
        list.addFirst("a");
        list.addFirst("b");
        list.addFirst("c");
        assertEquals(-1, list.indexOf("d"));
    }
    @Test
    public void stringLinkedListCreation() {
        LinkedList<String> list = new LinkedList<>();
        assertEquals(0, list.size());
    }
    @Test
    public void stringLinkedListAddFirst() {
        LinkedList<String> list = new LinkedList<>();
        list.addFirst("a");
        assertEquals(1, list.size());
        assertEquals(0, list.indexOf("a"));
    }

    @Test
    public void stringLinkedListAddLast() {
        LinkedList<String> list = new LinkedList<>();
        list.addFirst("b");
        list.addFirst("c");
        list.addFirst("d");
        list.addLast("a");
        assertEquals(4, list.size());
        assertEquals(3, list.indexOf("a"));
    }

    @Test
    public void stringLinkedListAdd() {
        LinkedList<String> list = new LinkedList<>();
        list.addFirst("b");
        list.addFirst("c");
        list.addFirst("d");
        list.add(1, "a");
        assertEquals(4, list.size());
        assertEquals(1, list.indexOf("a"));
    }
    @Test
    public void stringListListAddatFirstIndex() {
        LinkedList<String> list = new LinkedList<>();
        list.addFirst("b");
        list.addFirst("c");
        list.addFirst("d");
        list.add(0, "a");
        assertEquals(4, list.size());
        assertEquals(0, list.indexOf("a"));
    }

    @Test
    public void stringLinkedListAddatLastIndex() {
        LinkedList<String> list = new LinkedList<>();
        list.addFirst("b");
        list.addFirst("c");
        list.addFirst("d");
        list.add(3, "a");
        assertEquals(4, list.size());
        assertEquals(3, list.indexOf("a"));
    }


    @Test
    public void stringLinkedListRemoveFirst() {
        LinkedList<String> list = new LinkedList<>();
        list.addFirst("b");
        list.addFirst("c");
        list.addFirst("d");
        list.removeFirst();
        assertEquals(2, list.size());
        assertEquals(1, list.indexOf("b"));
    }

    @Test
    public void stringLinkedListRemoveLast() {
        LinkedList<String> list = new LinkedList<>();
        list.addFirst("b");
        list.addFirst("c");
        list.addFirst("d");
        list.removeLast();
        assertEquals(2, list.size());
        assertEquals(0, list.indexOf("d"));
    }

    @Test
    public void stringLinkedListRemove() {
        LinkedList<String> list = new LinkedList<>();
        list.addFirst("b");
        list.addFirst("c");
        list.addFirst("d");
        list.remove(1);
        assertEquals(2, list.size());
        assertEquals(1, list.indexOf("b"));
    }

    @Test
    public void stringLinkedListRemoveAtFirstIndex() {
        LinkedList<String> list = new LinkedList<>();
        list.addFirst("b");
        list.addFirst("c");
        list.addFirst("d");
        list.remove(0);
        assertEquals(2, list.size());
        assertEquals(0, list.indexOf("c"));
    }

    @Test
    public void stringLinkedListRemoveAtLastIndex() {
        LinkedList<String> list = new LinkedList<>();
        list.addFirst("b");
        list.addFirst("c");
        list.addFirst("d");
        list.remove(2);
        assertEquals(2, list.size());
        assertEquals(1, list.indexOf("c"));
    }

    @Test
    public void stringLinkedListClear() {
        LinkedList<String> list = new LinkedList<>();
        list.addFirst("b");
        list.addFirst("c");
        list.addFirst("d");
        list.clear();
        assertEquals(0, list.size());
    }

    @Test
    public void stringLinkedListRemoveFirstOccurrence() {
        LinkedList<String> list = new LinkedList<>();
        list.addFirst("b");
        list.addFirst("c");
        list.addFirst("d");
        list.addFirst("c");
        list.removeFirstOccurrence("c");
        assertEquals(3, list.size());
        assertEquals(1, list.indexOf("c"));
    }

    @Test
    public void stringLinkedListRemoveFirstOccurenceMultiples() {
        LinkedList<String> list = new LinkedList<>();
        list.addFirst("b");
        list.addFirst("c");
        list.addFirst("d");
        list.addFirst("c");
        list.removeFirstOccurrence("c");
        assertEquals(3, list.size());
        assertEquals(1, list.indexOf("c"));
    }

    @Test
    public void stringLinkedListRemoveFirstOccurenceNotFound() {
        LinkedList<String> list = new LinkedList<>();
        list.addFirst("b");
        list.addFirst("c");
        list.addFirst("d");
        list.addFirst("c");
        list.removeFirstOccurrence("a");
        assertEquals(4, list.size());
        assertTrue(list.removeFirstOccurrence("b"));
    }

    @Test
    public void stringLinkedListRemoveLastOccurrence() {
        LinkedList<String> list = new LinkedList<>();
        list.addFirst("c");
        list.addFirst("b");
        list.addFirst("d");
        list.addFirst("c");
        list.removeLastOccurrence("c");
        assertEquals(3, list.size());
        assertEquals(2, list.indexOf("b"));
    }
    @Test
    public void stringLinkedListRemoveLastOccurrenceNotFound() {
        LinkedList<String> list = new LinkedList<>();
        list.addFirst("c");
        list.addFirst("b");
        list.addFirst("d");
        list.addFirst("c");
        list.removeLastOccurrence("a");
        assertEquals(4, list.size());
        assertFalse(list.removeLastOccurrence("fdsf"));
    }

    @Test
    public void stringLinkedListContains() {
        LinkedList<String> list = new LinkedList<>();
        list.addFirst("c");
        list.addFirst("b");
        list.addFirst("d");
        list.addFirst("c");
        assertTrue(list.contains("c"));
    }

    @Test
    public void stringLinkedListContainsNotFound() {
        LinkedList<String> list = new LinkedList<>();
        list.addFirst("c");
        list.addFirst("b");
        list.addFirst("d");
        list.addFirst("c");
        assertFalse(list.contains("a"));
    }

    @Test
    public void stringLinkedListtoString() {
        LinkedList<String> list = new LinkedList<>();
        list.addFirst("c");
        list.addFirst("b");
        list.addFirst("d");
        list.addFirst("c");
        assertEquals("[c, d, b, c]", list.toString());
    }

    //rewrite all test for Integers
    @Test
    public void intLinkedListAddFirst() {
        LinkedList<Integer> list = new LinkedList<>();
        list.addFirst(1);
        list.addFirst(2);
        list.addFirst(3);
        assertEquals(3, list.size());
        assertEquals(2, list.indexOf(1));
    }

    @Test
    public void intLinkedListAddLast() {
        LinkedList<Integer> list = new LinkedList<>();
        list.addLast(1);
        list.addLast(2);
        list.addLast(3);
        assertEquals(3, list.size());
        assertEquals(2, list.indexOf(3));
    }

    @Test
    public void intLinkedListAddatIndex() {
        LinkedList<Integer> list = new LinkedList<>();
        list.addFirst(1);
        list.addFirst(2);
        list.addFirst(3);
        list.add(1, 4);
        assertEquals(4, list.size());
        assertEquals(1, list.indexOf(4));
    }

    @Test
    public void intLinkedListAddatFirstIndex() {
        LinkedList<Integer> list = new LinkedList<>();
        list.addFirst(1);
        list.addFirst(2);
        list.addFirst(3);
        list.add(0, 4);
        assertEquals(4, list.size());
        assertEquals(0, list.indexOf(4));
    }

    @Test
    public void intLinkedListAddatLastIndex() {
        LinkedList<Integer> list = new LinkedList<>();
        list.addFirst(1);
        list.addFirst(2);
        list.addFirst(3);
        list.add(3, 4);
        assertEquals(4, list.size());
        assertEquals(3, list.indexOf(4));
    }





    @Test
    public void intLinkedListRemoveFirst() {
        LinkedList<Integer> list = new LinkedList<>();
        list.addFirst(1);
        list.addFirst(2);
        list.addFirst(3);
        list.removeFirst();
        assertEquals(2, list.size());
        assertEquals(1, list.indexOf(1));
    }

    @Test
    public void intLinkedListRemoveLast() {
        LinkedList<Integer> list = new LinkedList<>();
        list.addFirst(1);
        list.addFirst(2);
        list.addFirst(3);
        list.removeLast();
        assertEquals(2, list.size());
        assertEquals(1, list.indexOf(2));
    }

    @Test
    public void intLinkedListRemoveatIndex() {
        LinkedList<Integer> list = new LinkedList<>();
        list.addFirst(1);
        list.addFirst(2);
        list.addFirst(3);
        list.add(1, 4);
        list.remove(1);
        assertEquals(3, list.size());
        assertEquals(1, list.indexOf(2));
    }

    @Test
    public void intLinkedListRemoveatFirstIndex() {
        LinkedList<Integer> list = new LinkedList<>();
        list.addFirst(1);
        list.addFirst(2);
        list.addFirst(3);
        list.remove(0);
        assertEquals(2, list.size());
        assertEquals(0, list.indexOf(2));
    }

    @Test
    public void intLinkedListRemoveatLastIndex() {
        LinkedList<Integer> list = new LinkedList<>();
        list.addFirst(1);
        list.addFirst(2);
        list.addFirst(3);
        list.add(3, 4);
        list.remove(3);
        assertEquals(3, list.size());
        assertEquals(2, list.indexOf(1));
    }

    @Test
    public void intLinkedListtoString() {
        LinkedList<Integer> list = new LinkedList<>();
        list.addFirst(1);
        list.addFirst(2);
        list.addFirst(3);
        assertEquals("[3, 2, 1]", list.toString());
    }

    @Test
    public void intLinkedListaddLastOneItem() {
        LinkedList<Integer> list = new LinkedList<>();
        list.addLast(1);
        assertEquals(1, list.size());
        assertEquals(0, list.indexOf(1));
    }

    @Test
    public void  intremoveFirstOneItem() {
        LinkedList<Integer> list = new LinkedList<>();
        list.addLast(1);
        list.removeFirst();
        assertEquals(0, list.size());
    }
    @Test
    public void intremoveLastOneItem() {
        LinkedList<Integer> list = new LinkedList<>();
        list.addLast(1);
        list.removeLast();
        assertEquals(0, list.size());
    }

    @Test
    public void intRemoveOneItem() {
        LinkedList<Integer> list = new LinkedList<>();
        list.addLast(1);
        list.remove(0);
        assertEquals(0, list.size());
    }

    @Test
    public void intLinkedListRemoveFirstDataReturned() {
        LinkedList<Integer> list = new LinkedList<>();
        list.addFirst(1);
        list.addFirst(2);
        list.addFirst(3);
        assertEquals(3, list.removeFirst());
    }

    @Test
    public void stringLinkedListRemoveFirstDataReturned() {
        LinkedList<String> list = new LinkedList<>();
        list.addFirst("a");
        list.addFirst("b");
        list.addFirst("c");
        assertEquals("c", list.removeFirst());
    }

    @Test
    public void stringLinkedListRemoveLastDataReturned() {
        LinkedList<String> list = new LinkedList<>();
        list.addFirst("a");
        list.addFirst("b");
        list.addFirst("c");
        assertEquals("a", list.removeLast());
    }

    @Test
    public void stringLinkedListRemoveDataReturned() {
        LinkedList<String> list = new LinkedList<>();
        list.addFirst("a");
        list.addFirst("b");
        list.addFirst("c");
        assertEquals("b", list.remove(1));
    }

    @Test
    public void addFirstExceptionCheck() {
        LinkedList<String> list = new LinkedList<>();
        assertThrows(IllegalArgumentException.class, () -> list.addFirst(null));
    }

    @Test
    public void addLastExceptionCheck() {
        LinkedList<String> list = new LinkedList<>();
        assertThrows(IllegalArgumentException.class, () -> list.addLast(null));
    }

    @Test
    public void addExceptionCheck() {
        LinkedList<String> list = new LinkedList<>();
        assertThrows(IllegalArgumentException.class, () -> list.add(0, null));
    }

    @Test
    public void addIndexOutOfBoundsExceptionCheck() {
        LinkedList<String> list = new LinkedList<>();
        assertThrows(IndexOutOfBoundsException.class, () -> list.add(1, "a"));
    }

    @Test
    public void addIndexOutOfBoundsExceptionCheckWithData() {
        LinkedList<String> list = new LinkedList<>();
        list.addFirst("a");
        assertThrows(IndexOutOfBoundsException.class, () -> list.add(2, "a"));
    }

    @Test
    public void addIndexOutOfBoundsExceptionCheckWithData2() {
        LinkedList<String> list = new LinkedList<>();
        list.addFirst("a");
        assertThrows(IndexOutOfBoundsException.class, () -> list.add(-1, "a"));
    }

    @Test
    public void indexOfExceptionCheck() {
        LinkedList<String> list = new LinkedList<>();
        assertThrows(IllegalArgumentException.class, () -> list.indexOf(null));
    }

    @Test
    public void emptyListRemoveFirstExceptionCheck() {
        LinkedList<String> list = new LinkedList<>();
        assertThrows(NoSuchElementException.class, () -> list.removeFirst());
    }

    @Test
    public void emptyListRemoveLastExceptionCheck() {
        LinkedList<String> list = new LinkedList<>();
        assertThrows(NoSuchElementException.class, () -> list.removeLast());
    }

    @Test
    public void indexOutOfBoundsRemoveExceptionCheck() {
        LinkedList<String> list = new LinkedList<>();
        assertThrows(IndexOutOfBoundsException.class, () -> list.remove(0));
    }

    @Test
    public void indexOutOfBoundsRemoveExceptionCheckWithData() {
        LinkedList<String> list = new LinkedList<>();
        list.addFirst("a");
        list.addFirst("b");
        list.addFirst("c");
        assertThrows(IndexOutOfBoundsException.class, () -> list.remove(3));
    }

    @Test
    public void indexOutOfBoundsRemoveExceptionCheckWithDataNegativeIndex() {
        LinkedList<String> list = new LinkedList<>();
        list.addFirst("a");
        list.addFirst("b");
        list.addFirst("c");
        assertThrows(IndexOutOfBoundsException.class, () -> list.remove(-1));
    }

    @Test
    public void removeFirstOccurenceExceptionCheck() {
        LinkedList<String> list = new LinkedList<>();
        assertThrows(IllegalArgumentException.class, () -> list.removeFirstOccurrence(null));
    }

    @Test
    public void removeLastOccurenceExceptionCheck() {
        LinkedList<String> list = new LinkedList<>();
        assertThrows(IllegalArgumentException.class, () -> list.removeLastOccurrence(null));
    }

    @Test
    public void containsExceptionCheck() {
        LinkedList<String> list = new LinkedList<>();
        assertThrows(IllegalArgumentException.class, () -> list.contains(null));
    }

    @Test
    public void stringLinkedListTostringempty() {
        LinkedList<String> list = new LinkedList<>();
        assertEquals("Empty List", list.toString());
    }


}