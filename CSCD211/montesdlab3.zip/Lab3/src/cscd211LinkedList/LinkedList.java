package cscd211LinkedList;

import java.util.NoSuchElementException;

public class LinkedList<T extends Comparable<T>> {
    private class Node{
        public T data;

        public Node next;

        public Node(final T data) {
            this.data = data;
            this.next = null;
        }

        public Node(final T data, final Node next) {
            this.data = data;
            this.next = next;
        }
    }

    private Node head;
    //private Node head = null;
    private int size;

    public LinkedList() {
        this.head = null;
        this.size = 0;
    }

    public int size() {
        return this.size;
    }

    public void clear() {
        this.head = null;
        this.size = 0;
    }

    public void addFirst(final T item) {
        if (item == null)
            throw new IllegalArgumentException("Not valid.");
        /*
        Node newNode = new Node(item, this.head);
        this.head = newNode;
        this.size++;
        */
        //Node nn = new Node(item, null);
        Node nn = new Node(item);
        nn.next = this.head;
        this.head = nn;
        this.size++;
    }

    public int indexOf(final T item) {
        if (item == null)
            throw new IllegalArgumentException("Not valid.");

        if (this.size == 0)
            return -1;
        int counter = 0;
        Node cur = this.head;

        while (cur != null) {
            if (cur.data.equals(item))
                return counter;

            counter++;
            cur = cur.next;
        }

        return -1;
    }

    public T removeFirst() {
        if (this.size == 0)
            throw new NoSuchElementException("Empty List.");

        T data = this.head.data;
        this.head = this.head.next;
        this.size--;
        return data;
    }

    public T removeLast() {
        if (this.size == 0)
            throw new NoSuchElementException("Empty List.");
        if (this.size == 1)
            return this.removeFirst();

        Node cur = this.head, prev = null;
        while (cur.next != null) {
            prev = cur;
            cur = cur.next;
        }
        prev.next = cur.next;
        this.size--;
        return (T) cur.data;
    }

    public T remove(final int index) {
        if (index >= this.size || index < 0) {
            throw new IndexOutOfBoundsException("Out of range.");
        }

        if (index == 0) {
            Node cur = this.head;
            this.head = this.head.next;
            cur.next = null;
            this.size--;
            return (T)cur.data;
        }
        int location = 0;

        Node cur = this.head.next;
        Node prev = this.head;

        for(; location != index; location++){
            prev = cur;
            cur = cur.next;
        }
        prev.next = cur.next;
        cur.next = null;
        this.size--;
        return (T)cur.data;
    }

    public void add(final int index, final T item) {
        if (item == null)
            throw new IllegalArgumentException("Not valid.");
        if (index < 0 || index > this.size)
            throw new IndexOutOfBoundsException("Out of range.");
        //if (index == 0)
          //  this.addFirst(item);
        this.head = new Node(item, this.head.next);
        this.size++;
        if(index == 0)
            this.addFirst(item);//copy

        else{
            Node cur = this.head, prev = null;
            Node nn = new Node(item, prev.next);
            prev.next = nn;
            this.size++;
            for (int x = 0; x < index; x++) {
                prev = cur;
                cur = cur.next;
            }
        }
    }

    public boolean removeLastOccurrence(final T item) {
        if (item == null)
            throw new IllegalArgumentException("Not valid.");
        if (this.size == 0)
            return false;

        int index = -1, x = 0;
        Node cur = this.head;
        for (; cur != null; cur = cur.next) {
            if (cur.data.equals(item))
                index = x;
            x++;
        }
        if (index == -1)
            return false;
        this.remove(index);
        return true;
    }

    public boolean removeFirstOccurrence(final T item) {
        if (item == null)
            throw new IllegalArgumentException("Not valid.");
        if(this.size == 0)
            return false;
        Node cur = this.head;
        Node prev = null;
        while(cur != null){
            if(cur.data.equals(item)) {
                if (prev == null) {
                    this.head = cur.next;
                } else {
                    prev.next = cur.next;
                }
                this.size--;
                return true;
            }
            prev = cur;
            cur= cur.next;
        }
        return false;
    }

    public void addLast(final T item) {
        if (item == null)
            throw new IllegalArgumentException("Not valid.");

        if (this.size == 0)
            this.addFirst(item);
        else {
            Node nn = new Node(item);
            Node cur = this.head;
            while (cur.next != null)
                cur = cur.next;
            cur.next = nn;
            this.size++;
        }
    }

    public String toString() {
        if (this.size == 0)
            return "Empty List";

        String str = "";
        Node cur = this.head;
        while (cur != null) {
            if (cur.next == null)
                str += cur.data;
            else {
                str += cur.data + ", ";
            }
            cur = cur.next;
        }
        return "["+ str + "]";
    }

    public boolean contains(final T item) {
        if (item == null)
            throw new IllegalArgumentException("Not valid.");

        if(size == 0)
            return false;
        int counter = 0;
        Node cur = this.head;

        if(!(indexOf(item)== -1))
            return true;

        return false;
        }
    } //end of class



