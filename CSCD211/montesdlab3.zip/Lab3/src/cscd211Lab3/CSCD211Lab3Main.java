package cscd211Lab3;

import java.util.Scanner;

import cscd211LinkedList.*;

/**
 * The class that contains main and is used for testing our LinkedList code
 * All preconditions will be checked and all parameters will be passed as final
 */
public class CSCD211Lab3Main
{
    /**
     * The main method. The information about this method is describe above.
     * 
     * @param args
     * Any command line parameters that are passed in. If there are
     * any they will be ignored by the program
     */
   public static void main(String [] args)
   {
      boolean res =  false;
      String str = null, item = null;
      int choice = 0, result = 0, index = 0;
      
      Scanner kb = new Scanner(System.in);
      
      LinkedList <String> myList = new LinkedList<>();
      
      do
      {
         choice = CSCD211Lab3Main.menu(kb);
         
         switch(choice)
         {
            case 1:  System.out.println(myList);
                     break;
                     
            case 2:  str = CSCD211Lab3Main.buildAString(kb);
                     myList.addFirst(str);
                     break;
            
            case 3:  str = CSCD211Lab3Main.buildAString(kb);
                     myList.addLast(str);
                     break;
            
            case 4:  str = CSCD211Lab3Main.buildAString(kb);
                     index = CSCD211Lab3Main.readIndex(kb);
                     myList.add(index, str);
                     break;

            case 5:  str = CSCD211Lab3Main.buildAString(kb);
                     res = myList.contains(str);
                     System.out.println("The results of contains " + res);
                     break;

            case 6:  str = CSCD211Lab3Main.buildAString(kb);
                     result = myList.indexOf(str);
                     System.out.println("The results of indexOf " + result);
                     break;

            case 7:  item = myList.removeFirst();
                     System.out.println("The results from remove " + item);
                     break;

            case 8:  item = myList.removeLast();
                     System.out.println("The results from remove " + item);
                     break;

            case 9:  index = CSCD211Lab3Main.readIndex(kb);
                     item = myList.remove(index);
                     System.out.println("The results from remove " + item);
                     break;

            case 10: str = CSCD211Lab3Main.buildAString(kb);
                     res = myList.removeFirstOccurrence(str);
                     System.out.println("The results of contains " + res);
                     break;
                     
            case 11: str = CSCD211Lab3Main.buildAString(kb);
                     res = myList.removeLastOccurrence(str);
                     System.out.println("The results of contains " + res);
                     break;
                     
            case 12: myList.clear();
                     break;
                     
            case 13: System.out.println("List size: " + myList.size());
                     break;            

            case 14: System.out.println("Program ending");
            		 break;
            		 
            default: throw new IllegalArgumentException("Main Range outside 1 - 14");
         
         }// end switch
      
      }while(choice != 14);
      
      kb.close();
   
   }// end main
   
   /**
    * menu method for testing your linked list
    * <br>  1) Print the List
    * <br>  2) Create a BoxCar and addFirst
    * <br>  3) Create a BoxCar and addLast
    * <br>  4) Create a BoxCar, read and index and add -- at the index
    * <br>  5) Create a BoxCar, check the list to see if the list contains the BoxCar
    * <br>  6) Create a BoxCar, find the indexOf that BoxCar
    * <br>  7) removeFirst
    * <br>  8) removeLast
    * <br>  9) Read index remove Node at that index
    * <br> 10) Create a BoxCar and removeFirstOccurrence of that BoxCar
    * <br> 11) Create a BoxCar and removeLastOccurrence of that BoxCar
    * <br> 12) clear the list
    * <br> 13) Print the size of the list
    * <br> 14) Quit
    * <br> You must ensure the value entered in within range
    *
    * @param kb Representing the Scanner Object
    * @return int  - The choice guaranteed by you to be between 1 and 14 inclusive
    *
    * @throws IllegalArgumentException if kb is null
    */
   public static int menu(final Scanner kb)
   {
	   if(kb == null)
		   throw new IllegalArgumentException("Scanner kb is null");
	   
	   int val;
	   do
	   {
		   System.out.print("Enter a menu choice ");
		   val = Integer.parseInt(kb.nextLine());
		   
	   }while(val < 1 || val > 14);
	   
	   return val;	
      
   }
   
   /**
    * Prompts the user for a String and reads the String from the keyboard
    *
    * @param kb The Scanner object
    * @return String The String read from the keyboard
    *
    * @throws IllegalArgumentException if kb is null
    */
   public static String buildAString(final Scanner kb)
   {
      if(kb == null)
		   throw new IllegalArgumentException("Scanner kb is null");
         
      System.out.print("Please enter a string ");
      String entry = kb.nextLine();
      
      return entry;      
   }
   
   
   /**
    * readIndex reads a value greater than -1
    *
    * @param kb The Scanner object
    * @return int - The index will be guaranteed by you to be greater than -1
    *
    * @throws IllegalArgumentException if kb is null
    */
   public static int readIndex(final Scanner kb)
   {
      int index;
      do
      {
         System.out.print("Please enter an index >= 0 ");
         index = Integer.parseInt(kb.nextLine());
      }while(index < 0);
      
      return index;
   }
   


}// end class