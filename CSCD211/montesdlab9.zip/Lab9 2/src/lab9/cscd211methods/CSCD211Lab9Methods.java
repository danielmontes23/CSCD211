package lab9.cscd211methods;

import lab9.cscd211classes.players.BaseballPlayer;
import lab9.cscd211classes.players.HockeyPlayer;
import lab9.cscd211classes.players.FootballPlayer;
import lab9.cscd211classes.players.Player;
import lab9.cscd211classes.Team;
import java.util.*;
import java.util.Scanner;

public class CSCD211Lab9Methods {
    public static void fillArrayList(final Scanner fin, final ArrayList<Team> myTeam) throws CloneNotSupportedException {
        if (fin == null || myTeam == null)
            throw new IllegalArgumentException("Bad Params in fillArrayList");

        while (fin.hasNext()) {
            String city = fin.nextLine();
            int numTeams = Integer.parseInt(fin.nextLine());

            for (int x = 0; x < numTeams; x++) {

                String line = fin.nextLine();
                String type_sport = line.split(",")[0];
                String typename = line.split(",")[1].trim();

                int numPlayer = Integer.parseInt(fin.nextLine());

                Player[] player = new Player[numPlayer];
                for (int i = 0; i < numPlayer; i++) {

                    String nexL = fin.nextLine();

                    String name = nexL.split(",")[0].trim();

                    String ssn = nexL.split(",")[1].trim();
                    int salary = Integer.parseInt(nexL.split(",")[2].trim());
                    String pos = nexL.split(",")[3].trim();

                    if (type_sport.equalsIgnoreCase("football")) {
                        player[i] = new FootballPlayer(name, ssn, salary, pos, Integer.parseInt(nexL.split(",")[4].trim()), Integer.parseInt(nexL.split(",")[5].trim()));
                    } else if (type_sport.equalsIgnoreCase("baseball")) {
                        player[i] = new BaseballPlayer(name, ssn, salary, pos, Double.parseDouble(nexL.split(",")[4].trim()));
                    } else {
                        player[i] = new HockeyPlayer(name, ssn, salary, pos,
                                Integer.parseInt(nexL.split(",")[4].trim()));
                    }
                }

                myTeam.add(new Team(city.trim(), typename.trim(), player));
            }
        }
    }

    public static int menu(Scanner kb) {
        if (kb == null)
            throw new IllegalArgumentException("Scanner is null.");

        int choice;

        do {
            System.out.println("Please choose from the following");
            System.out.println("1) Print all Teams");
            System.out.println("2) Sort all Teams by city and team name");
            System.out.println("3) Sort all Teams by Payroll");
            System.out.println("4) Exit program");
            choice = kb.nextInt();
            kb.nextLine();
        } while (choice < 1 || choice > 4);

        return choice;
    }
}

