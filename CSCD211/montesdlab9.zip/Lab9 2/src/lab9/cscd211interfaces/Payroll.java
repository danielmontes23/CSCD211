package lab9.cscd211interfaces;

public interface Payroll {
    static final int BASE_PAYROLL = 1500000;

     int calculatePayroll();

}
