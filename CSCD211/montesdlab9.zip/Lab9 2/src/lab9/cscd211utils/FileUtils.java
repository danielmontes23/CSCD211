package lab9.cscd211utils;

import java.io.*;
import java.util.Scanner;

public class FileUtils {

    public FileUtils(){

    }

    public static File openInputFile(final String[] args){
        if(args == null || args.length < 1)
            throw new IllegalArgumentException("Args is null or less than 1.");

        File inf = new File(args[0]);
        if(!inf.exists())
            throw new IllegalArgumentException("File in args[0] does not exist");

        return inf;
    }

    public static int countRecords(final int num, final Scanner fin, final int linesPerRecord){
        if(fin == null || linesPerRecord < 1)
            throw new IllegalArgumentException("Bad parameters.");

        int count = 0;
        while(fin.hasNext()){
            fin.nextLine();
            count++;
        }
        if(count % linesPerRecord != 0)
            throw new RuntimeException("Invalid number of total lines.");
            return count / linesPerRecord;
    }

    public static File openInputFile(final Scanner kb){
        if(kb == null)
            throw new IllegalArgumentException("Scanner is null");

        return new File(kb.nextLine());
    }

    public static String readFileName(final Scanner kb, final String type){
        if(kb == null || type == null || type.isEmpty())
            throw new IllegalArgumentException("Bad parameters");

        System.out.printf("Please enter the name of the %s file ", type);
        String file = kb.nextLine();

        return file;
    }

    public static File openInputFile(final String fn){
        if(fn == null)
            throw new IllegalArgumentException("Bad parameters.");

        File inf = new File(fn);
        if(!inf.exists())
            throw new IllegalArgumentException("bad filename in openInputFile");
        return inf;
    }

    public static void displayFile(final Scanner fin){
        if(fin == null)
            throw new IllegalArgumentException("Bad parameters.");

        String str = "";
        while(fin.hasNext())
        {
            str = fin.nextLine();
            System.out.println(str);
        }
    }

    public static File openOutputFile(final String fn){
        if(fn == null || fn.isEmpty())
            throw new IllegalArgumentException("Bad parameters.");

        File out = new File(fn);
        return out;
    }

    public static void displayFile(final Scanner fin, final PrintStream fout){
        if(fin == null || fout == null)
            throw new IllegalArgumentException("Bad parameters.");

        while(fin.hasNext())
        {
            fout.println(fin.nextLine());
        }
    }

    public static PrintStream openOutputFile(final File outf) throws Exception{
        if(outf == null)
            throw new IllegalArgumentException("File is null.");

        PrintStream fout = new PrintStream(outf);
        return fout;
    }
}
