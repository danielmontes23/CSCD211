package lab9.cscd211classes.players;

import java.text.DecimalFormat;

public class BaseballPlayer extends Player implements Cloneable{

    protected double batAvg;

    public BaseballPlayer(final String name, final String ssn, final int salary, final String position, final double batAvg){
        super(name, ssn, salary, position);
        if(batAvg < 0)
            throw new IllegalArgumentException("Bad Params in BaseballPlayer Constructor");

        this.batAvg = batAvg;
    }

    @Override
    public String toString(){
        String str = "";
        str = super.toString() + "\t\t" + this.batAvg;
        return str;

    }


    @Override
    public BaseballPlayer clone() throws CloneNotSupportedException{
        return (BaseballPlayer) super.clone();
    }
}
