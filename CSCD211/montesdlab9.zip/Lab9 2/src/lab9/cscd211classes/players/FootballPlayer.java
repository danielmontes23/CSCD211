package lab9.cscd211classes.players;

public class FootballPlayer extends Player implements Cloneable{

    protected int jerseyNumber;

    protected int td;

    public FootballPlayer(final String name, final String ssn, final int salary, final String position, final int td, final int jerseyNumber){
        super(name, ssn, salary, position);
        if(jerseyNumber < 0 || td < 0)
            throw new IllegalArgumentException("Bad Params in FootballPlayer Constructor");
        if(name.isEmpty() || ssn.isEmpty() || position.isEmpty())
            throw new IllegalArgumentException("Bad Params in Player Constructor");

        this.td = td;
        this.jerseyNumber = jerseyNumber;
    }

    @Override
    public String toString(){
            String str = "";
            str = super.toString() +"\t\t"+this.td + "\t\t" + this.jerseyNumber;
            return str;
    }

    @Override
    public FootballPlayer clone() throws CloneNotSupportedException{
        return (FootballPlayer) super.clone();
    }
}
