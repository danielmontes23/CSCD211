package lab9.cscd211classes.players;

public class Player implements Cloneable{

    protected String name;

    protected String position;

    protected int salary;

    protected String ssn;

    protected Player(final String name, final String ssn, final int salary, final String position){
        if (name == null || ssn == null || position == null)
            throw new IllegalArgumentException("Bad Params in Player Constructor");
        this.name = name;
        this.ssn = ssn;
        this.salary = salary;
        this.position = position;
    }

    public String getName(){
        return this.name;
    }

    public String getPosition(){
        return this.position;
    }

    public int getSalary(){
        return this.salary;
    }

    public String getSsn(){
        return this.ssn;
    }

    public String toString(){
        return this.name + " " + this.ssn + " " + this.salary + " " + this.position;
        //the player's name, ssn, salary, and position
    }

    public Player clone() throws CloneNotSupportedException{
        return (Player) super.clone();
    }

}
