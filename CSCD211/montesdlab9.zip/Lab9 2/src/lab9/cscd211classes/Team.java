package lab9.cscd211classes;

import java.text.DecimalFormat;
import java.util.*;
import lab9.cscd211classes.players.Player;
import lab9.cscd211interfaces.Payroll;

public class Team implements Payroll, Comparable<Team> {

    protected String city;

    protected int payroll;

    protected ArrayList<Player> players;
    protected String teamName;

    public Team(final String city, final String teamName, final Player[] players) throws CloneNotSupportedException {
        if(city == null || teamName == null || players == null)
            throw new IllegalArgumentException("Bad Params in Team Constructor");
        this.city = city;
        this.teamName = teamName;
        this.players = new ArrayList<Player>(players.length);
        for (Player p : players) //enhanced for loop
            this.players.add(p.clone());

        this.players.trimToSize();

        this.payroll = this.calculatePayroll();
    }


    public String getCity() {
        return this.city;
    }


    public int getPayroll() {
        return this.payroll;
    }


    public ArrayList<Player> getPlayers() {
        return this.players;
    }


    public String getTeamName() {
        return this.teamName;
    }

    public int calculatePayroll() {
        int total = 0;

        for(int i = 0; i < players.size(); i++) {
            total += this.players.get(i).getSalary();
        }


        return total + BASE_PAYROLL;
    }

    public int compareTo(Team o) {
        if (o == null)
            throw new IllegalArgumentException("Object is null");

        int result = this.getCity().compareTo(o.getCity());
        if (result != 0)
            return result;
        return this.getTeamName().compareTo(o.getTeamName());
    }

    public String toString() {
        //items in "" represent the variables
        //"city" + " - " + "teamName" + " - " + "payroll (This should be properly formatted)"

        DecimalFormat df = new DecimalFormat("$#,###.00");

        String str = "";
        str = this.city + " - " + this.teamName + "\nPayroll: " + df.format(this.payroll) + "\n----------------------------------------------------------------------------\n";

        for (Player data : players) {
            str += data + "\n";

        }
        return str + "\n";

    }
}
