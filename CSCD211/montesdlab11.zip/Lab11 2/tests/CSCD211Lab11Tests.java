import org.junit.jupiter.api.Test;


import static lab11.cscd211recursion.CSCD211Count5s.count5s;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class CSCD211Lab11Tests {
    @Test
    public void baseCase(){
        assertEquals(0,count5s(0));
    }

    @Test
    public void fiveTest(){
        assertEquals(1,count5s(5));
    }

    @Test
    public void fiftyFiveTest(){
        assertEquals(2,count5s(55));
    }

    @Test
    public void zeroFivesTest(){
        assertEquals(0,count5s(123467890));
    }

    @Test
    public void lotsOfFivesTest(){
        assertEquals(9,count5s(555555555));
    }

    @Test
    public void twoFives(){
        assertEquals(2,count5s(125875));
    }

    @Test
    public void fiveFirstOnly(){
        assertEquals(1,count5s(512348));
    }

    @Test
    public void fiveEndOnly(){
        assertEquals(1, count5s(12345));
    }
    @Test
    public void oneOnly(){
        assertEquals(0, count5s(1));
    }

    @Test
    public void nineOnly(){
        assertEquals(0, count5s(9));
    }
}
