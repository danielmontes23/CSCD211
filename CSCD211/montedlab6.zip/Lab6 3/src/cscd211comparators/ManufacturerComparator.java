package cscd211comparators;

import cscd211inheritance.Engine;
import java.util.Comparator;

public class ManufacturerComparator implements Comparator<Engine>{

    public ManufacturerComparator(){

    }// end of constructor

    public int compare(final Engine e1, final Engine e2){
        return e1.getManufacturer().compareTo(e2.getManufacturer());
    }
}
