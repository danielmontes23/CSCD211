package cscd211inheritance;

public class TruckEngine extends Engine {

    private boolean diesel;

    public TruckEngine(final String manufacturer, final int horsePower, final boolean diesel){
        super(manufacturer, horsePower);
        //this.manufacturer = manufacturer;
        //this.horsePower = horsePower;
        this.diesel = diesel;
    }

    @Override
    public String toString(){
        if(diesel){
            return "Truck Engine - Manufacturer: " + getManufacturer() + " with HP of " + horsePower + " is a diesel engine";
        }
        else {
            return "Truck Engine - Manufacturer: " + getManufacturer() + " with HP of " + horsePower + " is NOT a diesel engine";
        }
    }

    @Override
    public int calcOutput(){
        int output = super.calcOutput();
        if(diesel){
            output = (output / 18);
            return output;
        }
        else{
            output = (output / 8);
        }
        return output;
    }
}
