package cscd211inheritance;

public class CarEngine extends Engine{

    public CarEngine(final String manufacturer, final int horsePower){
        super(manufacturer, horsePower);
    }// end of constructor

    public CarEngine(final int horsePower, final String manufacturer){
        //this.horsePower = horsePower;
        //this.manufacturer = manufacturer;
        super(horsePower, manufacturer);
    }// end of constructor #2

    @Override
    public String toString(){
        return "Car Engine - Manufacturer: " + getManufacturer() + " with HP of " + horsePower;
    }

    @Override
    public int calcOutput(){
        int num = super.calcOutput() / 12;
        return num;
    }
}
