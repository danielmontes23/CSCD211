import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import cscd211inheritance.*;
import cscd211comparators.*;
import cscd211lab6.*;


import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

import static org.junit.jupiter.api.Assertions.*;

public class cscd211Lab6Test {
    @Nested
    class ToString_CalcOutput_GetManufacture_GetHorsepower {

        private Engine ford = new Engine("Ford", 200);
        private Engine toyota = new Engine("Toyota", 250);
        private Engine dodge = new Engine("Dodge", 300);
        private Engine chevy = new Engine("Chevy", 350);

        private Engine fordTaurus = new CarEngine("Ford", 200);
        private Engine toyotaCamry = new CarEngine("Toyota", 250);
        private Engine dodgeCharger = new CarEngine("Dodge", 300);
        private Engine chevyImpala = new CarEngine("Chevy", 350);

        private Engine fordF150 = new TruckEngine("Ford", 200, false);
        private Engine toyotaTacoma = new TruckEngine("Toyota", 250, false);
        private Engine dodgeRam = new TruckEngine("Dodge", 1200, true);
        private Engine chevySilverado = new TruckEngine("Chevy", 1500, true);

        @Test
        public void ford() {
            assertEquals("Manufacturer: Ford with HP of 200", this.ford.toString());
        }

        @Test
        public void toyota() {
            assertEquals("Manufacturer: Toyota with HP of 250", this.toyota.toString());
        }

        @Test
        public void dodge() {
            assertEquals("Manufacturer: Dodge with HP of 300", this.dodge.toString());
        }

        @Test
        public void chevy() {
            assertEquals("Manufacturer: Chevy with HP of 350", this.chevy.toString());
        }

        @Test
        public void fordTaurus() {
            assertEquals("Car Engine - Manufacturer: Ford with HP of 200", this.fordTaurus.toString());
        }

        @Test
        public void toyotaCamry() {
            assertEquals("Car Engine - Manufacturer: Toyota with HP of 250", this.toyotaCamry.toString());
        }

        @Test
        public void dodgeCharger() {
            assertEquals("Car Engine - Manufacturer: Dodge with HP of 300", this.dodgeCharger.toString());
        }

        @Test
        public void chevyImpala() {
            assertEquals("Car Engine - Manufacturer: Chevy with HP of 350", this.chevyImpala.toString());
        }

        @Test
        public void fordF150() {
            assertEquals("Truck Engine - Manufacturer: Ford with HP of 200 is NOT a diesel engine", this.fordF150.toString());
        }

        @Test
        public void toyotaTacoma() {
            assertEquals("Truck Engine - Manufacturer: Toyota with HP of 250 is NOT a diesel engine", this.toyotaTacoma.toString());
        }

        @Test
        public void dodgeRam() {
            assertEquals("Truck Engine - Manufacturer: Dodge with HP of 1200 is a diesel engine", this.dodgeRam.toString());
        }

        @Test
        public void chevySilverado() {
            assertEquals("Truck Engine - Manufacturer: Chevy with HP of 1500 is a diesel engine", this.chevySilverado.toString());
        }

        @Test
        public void fordGetManufacturer() {
            assertEquals("Ford", this.ford.getManufacturer());
        }

        @Test
        public void toyotaGetManufacturer() {
            assertEquals("Toyota", this.toyota.getManufacturer());
        }

        @Test
        public void dodgeGetManufacturer() {
            assertEquals("Dodge", this.dodge.getManufacturer());
        }

        @Test
        public void chevyGetManufacturer() {
            assertEquals("Chevy", this.chevy.getManufacturer());
        }

        @Test
        public void fordTaurusGetManufacturer() {
            assertEquals("Ford", this.fordTaurus.getManufacturer());
        }

        @Test
        public void toyotaCamryGetManufacturer() {
            assertEquals("Toyota", this.toyotaCamry.getManufacturer());
        }

        @Test
        public void dodgeChargerGetManufacturer() {
            assertEquals("Dodge", this.dodgeCharger.getManufacturer());
        }

        @Test
        public void chevyImpalaGetManufacturer() {
            assertEquals("Chevy", this.chevyImpala.getManufacturer());
        }

        @Test
        public void fordF150GetManufacturer() {
            assertEquals("Ford", this.fordF150.getManufacturer());
        }

        @Test
        public void toyotaTacomaGetManufacturer() {
            assertEquals("Toyota", this.toyotaTacoma.getManufacturer());
        }

        @Test
        public void dodgeRamGetManufacturer() {
            assertEquals("Dodge", this.dodgeRam.getManufacturer());
        }

        @Test
        public void chevySilveradoGetManufacturer() {
            assertEquals("Chevy", this.chevySilverado.getManufacturer());
        }

        @Test
        public void fordCalcOutput() {
            assertEquals(40, this.ford.calcOutput());
        }

        @Test
        public void toyotaCalcOutput() {
            assertEquals(50, this.toyota.calcOutput());
        }

        @Test
        public void dodgeCalcOutput() {
            assertEquals(60, this.dodge.calcOutput());
        }

        @Test
        public void chevyCalcOutput() {
            assertEquals(70, this.chevy.calcOutput());
        }

        @Test
        public void fordTaurusCalcOutput() {
            assertEquals(3, this.fordTaurus.calcOutput());
        }

        @Test
        public void toyotaCamryCalcOutput() {
            assertEquals(4, this.toyotaCamry.calcOutput());
        }

        @Test
        public void dodgeChargerCalcOutput() {
            assertEquals(5, this.dodgeCharger.calcOutput());
        }

        @Test
        public void chevyImpalaCalcOutput() {
            assertEquals(5, this.chevyImpala.calcOutput());
        }

        @Test
        public void fordF150CalcOutput() {
            assertEquals(5, this.fordF150.calcOutput());
        }

        @Test
        public void toyotaTacomaCalcOutput() {
            assertEquals(6, this.toyotaTacoma.calcOutput());
        }

        @Test
        public void dodgeRamCalcOutput() {
            assertEquals(13, this.dodgeRam.calcOutput());
        }

        @Test
        public void chevySilveradoCalcOutput() {
            assertEquals(16, this.chevySilverado.calcOutput());
        }
    }

    @Nested
    class CompareTo{
        Engine ford = new Engine("Ford", 200);
        Engine ford2 = new Engine("For", 200);
        Engine ford3 = new Engine("Fords", 200);
        Engine ford4 = new Engine("Ford", 200);
        Engine ford5 = new Engine("Fordlol", 200);
        Engine dodgeCharger = new CarEngine("Dodge", 300);
        Engine dodgeCharger1 = new CarEngine("Dodg", 300);
        Engine dodgeCharger2 = new CarEngine("Dodges", 300);
        Engine dodgeCharger3 = new CarEngine("Dodge", 300);

        Engine ford150 = new TruckEngine("Ford", 200, false);
        Engine ford1501 = new TruckEngine("For", 200, false);
        Engine ford1502 = new TruckEngine("Fords", 200, false);
        Engine ford1503 = new TruckEngine("Ford", 200, true);

        Engine dodgeRam = new TruckEngine("Dodge", 1200, true);

        @Test
        public void fordCompareToAllFord() {
            assertEquals(1, this.ford.compareTo(this.ford2));
            assertEquals(-1, this.ford.compareTo(this.ford3));
            assertEquals(0, this.ford.compareTo(this.ford4));
            assertEquals(-3, this.ford.compareTo(this.ford5));
        }

        @Test
        public void fordCompareToOther() {
            assertEquals(-100, this.ford.compareTo(this.dodgeCharger));
            assertEquals(-1, this.ford.compareTo(this.ford1502));
            assertEquals(-0, this.ford.compareTo(this.ford1503));
            assertEquals(-100, this.ford.compareTo(this.dodgeCharger3));
        }

        @Test
        public void dodgeCompareToAllDodge() {
            assertEquals(1, this.dodgeCharger.compareTo(this.dodgeCharger1));
            assertEquals(-1, this.dodgeCharger.compareTo(this.dodgeCharger2));
            assertEquals(0, this.dodgeCharger.compareTo(this.dodgeCharger3));
        }

        @Test
        public void ford150CompareToAllFord150() {
            assertEquals(1, this.ford150.compareTo(this.ford1501));
            assertEquals(-1, this.ford150.compareTo(this.ford1502));
            assertEquals(0, this.ford150.compareTo(this.ford1503));
        }

        @Test
        public void fordCompareToDodgeRam() {
            assertEquals(-1000, this.ford.compareTo(this.dodgeRam));
        }

    }

    @Nested
    class ManufacturerComparators{
        Engine dodgeViper = new CarEngine("Dodge", 1000);
        Engine dodgeCharger = new CarEngine("Dodge", 300);
        Engine dodgeRam = new TruckEngine("Dodge", 1200, true);
        Engine dodge = new Engine("Dodge", 200);

        Engine corvette = new CarEngine("Chevy", 200);
        Engine stingray = new CarEngine("Chevy", 300);

        Engine lamboTruck = new TruckEngine("Lamborghini", 20000, true);
        Engine porsche = new Engine("Porsche", 10000);
        ManufacturerComparator comparator = new ManufacturerComparator();

        @Test
        public void dodgeComparator() {
            assertEquals(0, comparator.compare(dodge, dodge));
            assertEquals(0, comparator.compare(dodge, dodgeCharger));
            assertEquals(0, comparator.compare(dodge, dodgeRam));
            assertEquals(0, comparator.compare(dodge, dodgeViper));
        }

        @Test
        public void chevyComparator() {
            assertEquals(0, comparator.compare(corvette, corvette));
            assertEquals(0, comparator.compare(corvette, stingray));
        }

        @Test
        public void viperComparator() {
            assertEquals(1, comparator.compare(dodgeViper, this.stingray));
            assertEquals(0, comparator.compare(dodgeViper, this.dodgeCharger));
            assertEquals(-8, comparator.compare(dodgeViper, this.lamboTruck));
            assertEquals(-12, comparator.compare(dodgeViper, this.porsche));
        }

    }

    @Nested
    class Exceptions{
        @Test
        public void engineConstructorException() {
            assertThrows(IllegalArgumentException.class, () -> new Engine("Ford", 0));
            assertThrows(IllegalArgumentException.class, () -> new Engine(null, 1));
            assertThrows(IllegalArgumentException.class, () -> new Engine("  ", 1));
        }

        @Test
        public void engineConstructor2Exception() {
            assertThrows(IllegalArgumentException.class, () -> new Engine(1, "  "));
            assertThrows(IllegalArgumentException.class, () -> new Engine(0, "Ford"));
            assertThrows(IllegalArgumentException.class, () -> new Engine(1, null));
        }

        @Test
        public void carEngineConstructorException() {
            assertThrows(IllegalArgumentException.class, () -> new CarEngine("Ford", 0));
            assertThrows(IllegalArgumentException.class, () -> new CarEngine(null, 1));
            assertThrows(IllegalArgumentException.class, () -> new CarEngine("  ", 1));
        }

        @Test
        public void carEngineConstructor2Exception() {
            assertThrows(IllegalArgumentException.class, () -> new CarEngine(1, "  "));
            assertThrows(IllegalArgumentException.class, () -> new CarEngine(0, "Ford"));
            assertThrows(IllegalArgumentException.class, () -> new CarEngine(1, null));
        }

        @Test
        public void truckEngineConstructorException() {
            assertThrows(IllegalArgumentException.class, () -> new TruckEngine("Ford", 0, true));
            assertThrows(IllegalArgumentException.class, () -> new TruckEngine(null, 1, true));
            assertThrows(IllegalArgumentException.class, () -> new TruckEngine("  ", 1, true));
        }

    }

    @Nested
    class Main {


        private final PrintStream originalOut = System.out;
        private ByteArrayOutputStream testOut;


        @BeforeEach
        public void init() {
            testOut = new ByteArrayOutputStream();
            System.setOut(new PrintStream(testOut));
        }

        @AfterEach
        public void cleanUp() {
            System.setOut(originalOut);
        }

        @Test
        public void mainTest() {

            CSCD211Lab6.main(new String[0]);


            String mainOutput = "Car Engine - Manufacturer: General Motors with HP of 137 output of 2\n" +
                    "Truck Engine - Manufacturer: Ford with HP of 250 is a diesel engine output of 2\n" +
                    "Car Engine - Manufacturer: Toyota with HP of 134 output of 2\n" +
                    "Car Engine - Manufacturer: Ford with HP of 134 output of 2\n" +
                    "Truck Engine - Manufacturer: Toyota with HP of 200 is NOT a diesel engine output of 5\n" +
                    "\n" +
                    "Car Engine - Manufacturer: Ford with HP of 134\n" +
                    "Car Engine - Manufacturer: Toyota with HP of 134\n" +
                    "Car Engine - Manufacturer: General Motors with HP of 137\n" +
                    "Truck Engine - Manufacturer: Toyota with HP of 200 is NOT a diesel engine\n" +
                    "Truck Engine - Manufacturer: Ford with HP of 250 is a diesel engine\n" +
                    "\n" +
                    "Car Engine - Manufacturer: Ford with HP of 134\n" +
                    "Truck Engine - Manufacturer: Ford with HP of 250 is a diesel engine\n" +
                    "Car Engine - Manufacturer: General Motors with HP of 137\n" +
                    "Car Engine - Manufacturer: Toyota with HP of 134\n" +
                    "Truck Engine - Manufacturer: Toyota with HP of 200 is NOT a diesel engine\n\n";


            assertEquals(mainOutput, this.testOut.toString());
        }

    }

}

