import cscd211classes.*;
import cscd211comparators.*;

import org.junit.jupiter.api.Test;


import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.*;



public class FirstAuthorComparatorTest {
    // public Book(final String title, final String isbn, final int pages,
    //             final Publisher pubs, final String [] author)
    // author
    private Author author1 = new Author("a","b");
    private Author author2 = new Author("b","c");
    private Author author3 = new Author("c","d");
    private Author author4 = new Author("d","e");
    private Author author5 = new Author("e","f");
    private Author author6 = new Author("f","g");
    private Author author7 = new Author("g","h");
    private Author author8 = new Author("h","i");
    private Author author9 = new Author("i","j");

    private Author [] array1 = {author7,author2,author3,author4,author5,author6,author7,author1,author9};
    private Author [] array2 = {author6,author1,author3,author9,author5,author6,author7,author8,author9};
    private Author [] array3 = {author5,author2,author3,author4,author5,author6,author7,author8,author9};
    private Author [] array4 = {author4,author2,author3,author4,author5,author6,author7,author8,author9};
    private Author [] array5 = {author3,author2,author3,author4,author5,author6,author7,author8,author1};
    private Author [] array6 = {author2,author2,author3,author4,author1,author6,author7,author8,author9};
    private Author [] array7 = {author1,author2,author1,author4,author5,author6,author7,author8,author9};
    private Book book1 = new Book("alpha","one piece", 99,"Angry","blackbeard", array1);//7
    private Book book2 = new Book("pikachu","one piece", 99,"luffy","shanks", array4);//4
    private Book book3 = new Book("luffy","Seattle", 99,"luffy","shanks", array2);//6
    private Book book4 = new Book("zoro","one piece", 99,"luffy","shanks", array7);//1
    private Book book5 = new Book("zoro","one piece", 99,"luffy","shanks", array5);//3
    private Book book6 = new Book("taurus","Goku", 99,"luffy","Almost", array3);//5
    private Book book7 = new Book("Mouse","one piece", 99,"luffy","shanks", array6);//2

    Book [] unsortedArr = {book1,book2,book3,book4,book5,book6,book7};
    Book [] sortedArr = {book4,book7,book5,book2,book6,book3,book1};

    @Test
    public void firstAuthorComparator_sorting_test(){
        Arrays.sort(unsortedArr,new FirstAuthorComparator());
        assertArrayEquals(sortedArr,unsortedArr);
    }


}
