//lab packages I used the wildcard to pull everything.
import cscd211classes.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import static org.junit.jupiter.api.Assertions.*;


@TestMethodOrder(OrderAnnotation.class)
public class ExceptionsTest {
   private String title = "test";
   private String isbn = "test";
   private String first = "test";
   private String last = "test";
   private String name = "test";
   private String city = "test";
   private int pages = 1;

   private String [] author = new String[0];
   private Author [] author2 = new Author[0];
   private Publisher pub = new Publisher(name,city);

    @Test
    @Order(1)
    public void book_evc_null_test(){
        assertThrows(IllegalArgumentException.class, ()-> new Book(null,isbn,pages,name,city,author2));
        assertThrows(IllegalArgumentException.class, ()-> new Book(title,null,pages,name,city,author2));
        assertThrows(IllegalArgumentException.class, ()-> new Book(title,isbn,pages,null,city,author2));
    }
    @Test
    @Order(2)
    public void book_evc_null_and_zero_test(){
        assertThrows(IllegalArgumentException.class, ()-> new Book(title,isbn,pages,name,null,author2));
        assertThrows(IllegalArgumentException.class, ()-> new Book(title,isbn,0,name,city,author2));
        assertThrows(IllegalArgumentException.class, ()-> new Book(title,isbn,pages,name,city,null));
    }

    @Test
    @Order(3)
    public void book_evc_blank_test(){
        assertThrows(IllegalArgumentException.class, ()-> new Book("  ",isbn,pages,name,city,author2));
        assertThrows(IllegalArgumentException.class, ()-> new Book(title,"   ",pages,name,city,author2));
        assertThrows(IllegalArgumentException.class, ()-> new Book(title,isbn,pages,"   ",city,author2));
        assertThrows(IllegalArgumentException.class, ()-> new Book(title,isbn,pages,name,"   ",author2));
    }
    @Test
    @Order(4)
    public void book_evc2_null_test(){
        assertThrows(IllegalArgumentException.class, ()-> new Book(title,isbn,pages,pub,null));
        assertThrows(IllegalArgumentException.class, ()-> new Book(title,isbn,pages,null,author));
    }
    @Test
    @Order(5)
    public void book_evc2_null_and_zero_test(){
        assertThrows(IllegalArgumentException.class, ()-> new Book(null,isbn,pages,pub,author));
        assertThrows(IllegalArgumentException.class, ()-> new Book(title,null,pages,pub,author));
        assertThrows(IllegalArgumentException.class, ()-> new Book(title,isbn,0,pub,author));
    }

    @Test
    @Order(6)
    public void book_evc2_blank_test(){
        assertThrows(IllegalArgumentException.class, ()-> new Book("  ",isbn,pages,pub,author));
        assertThrows(IllegalArgumentException.class, ()-> new Book(title,"   ",pages,pub,author));
    }

    @Test
    @Order(7)
    public void author_evc_null_test(){
        assertThrows(IllegalArgumentException.class, () -> new Author(null,last));
        assertThrows(IllegalArgumentException.class, () -> new Author(first,null));
    }
    @Test
    @Order(8)
    public void author_evc_blank_test(){
        assertThrows(IllegalArgumentException.class, () -> new Author("  ",last));
        assertThrows(IllegalArgumentException.class, () -> new Author(first,"  "));
    }

    @Test
    @Order(9)
    public void publisher_evc_null_test(){
        assertThrows(IllegalArgumentException.class, () -> new Publisher(null,city));
        assertThrows(IllegalArgumentException.class, () -> new Publisher(name,null));
    }

    @Test
    @Order(10)
    public void publisher_evc_blank_test(){
        assertThrows(IllegalArgumentException.class, () -> new Publisher("   ",city));
        assertThrows(IllegalArgumentException.class, () -> new Publisher(name,"   "));
    }

    @Test
    @Order(10)
    public void compareTo_evc_blank_test(){
        Book test = new Book(title,isbn,pages,pub,author);
        Author test2 = new Author(first,last);

        assertThrows(IllegalArgumentException.class, () -> pub.compareTo(null));
        assertThrows(IllegalArgumentException.class, () -> test.compareTo(null));
        assertThrows(IllegalArgumentException.class, () -> test2.compareTo(null));
    }

}

