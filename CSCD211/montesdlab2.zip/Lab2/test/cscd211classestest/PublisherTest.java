import cscd211classes.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;

import java.io.*;
import java.util.Scanner;


import static org.junit.jupiter.api.Assertions.*;


@TestMethodOrder(OrderAnnotation.class)
public class PublisherTest {

    //Fields and methods for test methods
    private final PrintStream originalOut = System.out;
    private final InputStream originalIn = System.in;
    private ByteArrayOutputStream testOut;
    private ByteArrayInputStream testIn;

    private Scanner kb;

    @BeforeEach
    public void init() {
        testOut = new ByteArrayOutputStream();
        System.setOut(new PrintStream(testOut));
    }

    @AfterEach
    public void cleanUp() {
        System.setOut(originalOut);
        System.setIn(originalIn);
    }

    private void injectInput(String msg) {
        this.testIn = new ByteArrayInputStream((msg + System.lineSeparator()).getBytes());
        System.setIn(this.testIn);
        kb = new Scanner(testIn);
    }

 //publisher (name city) getpubName getCity compareTo only name  hashcode tostring name, city equals
    private Publisher lewis = new Publisher("Lewis Thomas","Valdosta");

    @Test
    @Order(1)
    public void evc_test_using_getters(){
        assertEquals("Lewis Thomas", lewis.getPubName());
        assertEquals("Valdosta", lewis.getPubCity());
    }

    @Test
    @Order(2)
    public void toString_test(){
        assertEquals("Lewis Thomas, Valdosta", lewis.toString());
    }

    @Test
    @Order(3)
    public void hashCode_test(){
        assertEquals(-1719460871,lewis.hashCode());
    }

    @Test
    @Order(4)
    public void compareTo_equals_test(){
        Publisher lewisClone = new Publisher("Lewis Thomas", "Spokane");
        assertTrue(lewis.compareTo(lewisClone) == 0);
    }
    @Test
    @Order(5)
    public void compareTo_less_than_test(){
        Publisher lewisClone = new Publisher("lewis Thomas", "Valdosta");
        assertTrue(lewis.compareTo(lewisClone) < 0);
    }
    @Test
    @Order(6)
    public void compareTo_greater_than_test(){
        Publisher lewisClone = new Publisher("Lewis Thomas1", "Spokane");
        assertTrue(lewisClone.compareTo(lewis) > 0);
    }

    @Test
    @Order(7)
    public void equals_test(){
        Publisher lewisClone = new Publisher("Lewis Thomas", "Valdosta");
        assertEquals(lewis,lewisClone);
        assertFalse(lewis.equals(null));
        assertTrue(lewis.equals(lewis));

    }

    @Test
    @Order(8)
    public void equals_false_test(){
        Publisher lewisClone = new Publisher("Lewis Thomas1", "Spokane");
        Publisher lewisClone1 = new Publisher("Lewis Thomas", "Spokane1");
        assertNotEquals(lewis, lewisClone);
        assertNotEquals(lewis,lewisClone1);
    }

}
