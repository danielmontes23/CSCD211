//lab packages I used the wildcard to pull everything.
import cscd211classes.*;



import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;
import static org.junit.jupiter.api.Assertions.*;


@TestMethodOrder(OrderAnnotation.class)
public class BookTest {

    //Fields and methods for test methods


    //test variables

    //Author creation
    private Author authorOne = new Author ("Lewis", "Thomas");
    private Author authorTwo = new Author ("Stu", "Steiner");
    private Author authorThree = new Author("Fraken", "Steiner");

    private Author author1 = new Author ("Lewis1", "Thomas");
    private Author author2 = new Author ("Stu1", "Steiner");
    private Author author3 = new Author("Fraken1", "Steiner");

    //Author Array
    private Author [] arr = {authorOne,authorTwo,authorThree};
    private Author [] arr2 = {author1,author2,author3};
    private Author stringCheck = new Author("lewis", "timothy thomas jr");
    private Author stringCheck2 = new Author("stu", "steiner");
    private Author stringCheck3 = new Author("mean", "person lewis");
    private Author [] stringArrayCheck= {stringCheck, stringCheck2,stringCheck3};
    private String [] authorNames = {"lewis timothy thomas jr   ", "stu steiner","mean     person   lewis   "};
    private String [] authorNames2= {"Lewis Thomas","Stu Steiner","Fraken Steiner"};

    //Publisher creation
    private Publisher pubOne = new Publisher("Lewis Thomas" ,"Valdosta");
    private Publisher pubTwo = new Publisher("Stu Steiner" ,"Spokane");

    //book creation
    private Book book1 = new Book("CSCD211","1234A",99,pubOne,authorNames);
    private Book book2 = new Book("CSCD211","1234B",99,"Lewis Thomas","Valdosta", arr);
    private Book book3 = new Book("CSCD211","1234B",99,"Lewis Thomas","Valdosta", arr2);
    private Book book4 = new Book("CSCD211","1234B",99,pubOne, authorNames2);


    @Order(1)
    @Test
    public void book_evc_author_array_check(){
        Author[] test = book2.getArrayAuthor();
        assertArrayEquals(arr, book2.getArrayAuthor());
    }
    @Order(2)
    @Test
    public void book_evc_string_array_check(){
        Author[] test = book4.getArrayAuthor();
        assertArrayEquals(arr, book4.getArrayAuthor());
    }
    @Order(3)
    @Test
    public void book_evc_author_array_memory_location_check(){
        Author[] test = book2.getArrayAuthor();
        for (int i = 0; i < test.length; i++)
            assertNotSame(test[i],arr[i]);
    }
    @Order(4)
    @Test
    public void book_evc_publisher_check(){
        assertEquals(pubOne,book1.getPublisher());
    }
    @Order(5)
    @Test
    public void book_evc_publisher_memory_location_check(){
        assertNotSame(pubOne ,book1.getPublisher());
    }

    @Order(6)
    @Test
    public void evc_primitive_check(){
        assertEquals(99,book1.getBookPages());
        assertEquals("CSCD211", book1.getBookTitle());
        assertEquals("1234A",book1.getISBN());
    }
    @Order(7)
    @Test
    public void evc_primitive_string_array_check(){
        assertEquals(99,book4.getBookPages());
        assertEquals("CSCD211", book4.getBookTitle());
        assertEquals("1234B",book4.getISBN());
    }
    @Order(8)
    @Test
    public void getFirstAuthor_test(){
        assertEquals(authorOne,book2.getFirstAuthor());
    }

    @Order(9)
    @Test
    public void hashcode(){
        assertEquals(1820168096,book1.hashCode());
    }

    @Order(10)
    @Test
    public void setISBN_test(){
        book1.setISBN("lets go!");
        assertEquals("lets go!", book1.getISBN());
    }

    @Order(11)
    @Test
    public void setTitle_test(){
        book1.setTitle("You got this");
        assertEquals("You got this", book1.getBookTitle());
    }

    @Order(12)
    @Test
    public void setPages_test(){
        book1.setPages(2);
        assertEquals(2, book1.getBookPages());
    }

    @Order(13)
    @Test
    public void equals_test() {
        assertEquals(book2, book4);
    }

    @Order(14)
    @Test
    public void not_equals_test() {
        assertNotEquals(book1,book2);
    }

    @Order(15)
    @Test
    public void not_equals_null_test() {
        assertFalse(book1.equals(null));
    }

    @Order(16)
    @Test
    public void compareTo_test(){
        //pub title isbn
        assertTrue(book1.compareTo(book1) == 0);
        assertTrue(book2.compareTo(book4) == 0);
    }

    @Order(17)
    @Test
    public void compareTo_less_than_test(){
        Publisher pubTest = new Publisher("Lawis t", "idk");
        Publisher pubTest2 = new Publisher("Lewis Thomas", "idk");
        Book bookTest = new Book("CSCD311","FSDFSDFSDFDSFSDF", 99,pubTest, this.authorNames2);
        Book bookTest2 = new Book("CSCD211","0", 99,pubTest, this.authorNames2);
        assertTrue(bookTest.compareTo(book4)<0);
        assertTrue(bookTest2.compareTo(book4)<0);
    }


    @Order(18)
    @Test
    public void compareTo_greater_than_test(){
        Publisher pubTest = new Publisher("Lewis Thomas", "idk");
        Book bookTest = new Book("CSCD211","1234C", 99,pubTest, this.authorNames2);
        Book bookTest2 = new Book("CSCD311","0", 99,pubTest, this.authorNames2);
        assertTrue(bookTest.compareTo(book4)>0);
        assertTrue(bookTest2.compareTo(book4)>0);
    }

    @Order(19)
    @Test
    public void toString_test(){
        assertEquals("CSCD211, ISBN: 1234B", book4.toString());
    }

    @Order(20)
    @Test
    public void book_evc_string_array_space_check(){
        assertArrayEquals(stringArrayCheck, book1.getArrayAuthor());
    }
}





