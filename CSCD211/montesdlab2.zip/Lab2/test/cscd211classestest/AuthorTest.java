import cscd211classes.*;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.api.MethodOrderer.OrderAnnotation;

import java.io.*;
import java.util.Scanner;


import static org.junit.jupiter.api.Assertions.*;


@TestMethodOrder(OrderAnnotation.class)
public class AuthorTest {

    //Fields and methods for test methods
    private final PrintStream originalOut = System.out;
    private final InputStream originalIn = System.in;
    private ByteArrayOutputStream testOut;
    private ByteArrayInputStream testIn;

    private Scanner kb;

    @BeforeEach
    public void init() {
        testOut = new ByteArrayOutputStream();
        System.setOut(new PrintStream(testOut));
    }

    @AfterEach
    public void cleanUp() {
        System.setOut(originalOut);
        System.setIn(originalIn);
    }

    private void injectInput(String msg) {
        this.testIn = new ByteArrayInputStream((msg + System.lineSeparator()).getBytes());
        System.setIn(this.testIn);
        kb = new Scanner(testIn);
    }

    private Author franken = new Author ("Stu", "Steiner");
//getFirstName, getLastName Author(first last toString last, first equals hashcode objects.hash compareto last then first

    @Test
    @Order(1)
    public void evc_test_using_gets(){
        assertEquals("Stu", franken.getFirstName());
        assertEquals("Steiner", franken.getLastName());
    }

    @Test
    @Order(2)
    public void toString_test(){
        assertEquals("Steiner, Stu", franken.toString());
    }

    @Test
    @Order(3)
    public void hashCode_test(){
        assertEquals(-226522941, franken.hashCode());
    }

    @Test
    @Order(4)
    public void equals_test(){
        Author franken2 = new Author ("Stu", "Steiner");
        assertEquals(franken, franken2);
        assertEquals(franken, franken);
    }

    @Test
    @Order(5)
    public void equals_not_test(){
        Author franken2 = new Author ("Stu1", "Steiner");
        assertNotEquals(franken, franken2);
        assertFalse(franken.equals(null));
    }

    @Test
    @Order(6)
    public void compareTo_equality_test(){
        Author franken2 = new Author ("Stu", "Steiner");
        assertTrue(franken.compareTo(franken2) == 0);
        assertTrue(franken.compareTo(franken) == 0);
    }

    @Test
    @Order(7)
    public void compareTo_less_than_test(){
        Author franken2 = new Author ("stu", "Steiner");
        Author franken3 = new Author ("Stu", "steiner");
        assertTrue(franken.compareTo(franken2) < 0);
        assertTrue(franken.compareTo(franken3) < 0);
    }

    @Test
    @Order(8)
    public void compareTo_greater_than_test() {
        Author franken2 = new Author("Stu1", "Steiner");
        Author franken3 = new Author("Stu", "Steiner!");
        assertTrue(franken2.compareTo(franken) > 0);
        assertTrue(franken3.compareTo(franken) > 0);
    }

}

