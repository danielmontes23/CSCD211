package cscd211classes;

import java.util.Objects;

public class Author implements Comparable<Author> {

    private final String first;
    private final String last;

    public Author(final String first, final String last){
        if(first == null || last == null)
            throw new NullPointerException("Bad parameters.");
        if(first.isEmpty() || last.isEmpty())
            throw new IllegalArgumentException("Bad parameters.");

        this.first = first;
        this.last = last;
    }

    public int compareTo(final Author another){
        if(another == null)
            throw new IllegalArgumentException("Bad parameters.");

        int result = this.last.compareTo(another.last);

        if(result != 0)
            return result;
        return this.first.compareTo(another.first);
    }

    public String getFirstName() {
        return first;
    }

    public String getLastName() {
        return last;
    }

    @Override
    public String toString() {
        return this.last + ", " + this.first;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Author author)) return false;
        return Objects.equals(first, author.first) && Objects.equals(last, author.last);
    }

    @Override
    public int hashCode() {
        return Objects.hash(first, last);
    }
}
