package cscd211classes;

//import java.util.Objects;

import java.util.Objects;

public class Publisher implements Comparable<Publisher> {
    private final String city;
    private final String name;

    public Publisher(final String name, final String city) {
        if(name == null || city == null)
            throw new IllegalArgumentException("Bad parameters.");
        if(name.isEmpty() || city.isEmpty())
            throw new IllegalArgumentException("Bad parameters.");

        this.name = name;
        this.city = city;
    }

    public int compareTo(final Publisher another){
        if(another == null)
            throw new IllegalArgumentException("Publisher is null.");

        return this.name.compareTo(another.name);
    }
    public String getPubName() {
        return name;
    }

    public String getPubCity() {
        return city;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Publisher publisher)) return false;
        return Objects.equals(city, publisher.city) && Objects.equals(name, publisher.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name, city);
    }

    @Override
    public String toString() {
        return this.name + ", " + this.city;
    }
}
