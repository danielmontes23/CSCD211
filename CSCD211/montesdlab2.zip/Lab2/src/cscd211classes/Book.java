package cscd211classes;

//import java.util.Objects;

public class Book implements Comparable<Book> {
    private final Author[] authors;
    private String isbn;
    private int pages;
    private final Publisher pub;
    private String title;

    public Book(final String title, final String isbn, final int pages, final Publisher pubs, final String[] author) {
        this.title = title;
        this.isbn = isbn;
        this.pages = pages;
        this.pub = new Publisher(pubs.getPubName(), pubs.getPubCity());
        this.authors = new Author[author.length];

        for (int x = 0; x < this.authors.length; x++) {
            String str = author[x];
            String[] name = str.split(" ");
            if (name.length == 2)
                this.authors[x] = new Author(name[0].strip(), name[1].strip());
                //(temp[0], temp[1]);
            else {
                String temp = "";
                for (x = 1; x < name.length; x++)
                    temp = temp + name[x].strip() + " ";
            }
            //int temp;
            //String temp;
            //this.authors[x] = new Author(name[0].strip(), temp.strip());
        }

    }

    public Book(final String title, final String isbn, final int pages, final String pubName, final String pubCity, final Author[] array) {
        if (title != null && !title.isBlank() && isbn != null && !isbn.isBlank() && pages >= 1 && pubName != null && pubName.isBlank() && pubCity != null && !pubCity.isBlank() && array != null)
            throw new IllegalArgumentException("Bad parameters.");
        this.title = title;
        this.isbn = isbn;
        this.pages = pages;
        this.pub = new Publisher(pubName, pubCity);
        this.authors = new Author[array.length];
    }

    public int compareTo(final Book passedIn) {
        return 0;
    }
//        if (passedIn == null) {
//            throw new IllegalArgumentException("Bad parameters.");
//        } else {
//            int result = this.pub.compareTo(passedIn.pub);
//        }
//        int result;
//        if (result != 0) {
//            return result;
//        } else {
//            result = this.title.compareTo(passedIn.title);
//            return result != 0 ? result : this.isbn.compareTo(passedIn.getISBN());
//        }
//    }

    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        } else if (!(obj instanceof Book)) {
            return false;
        } else {
            Book passedIn = (Book)obj;
            return this.title.equals(passedIn.getBookTitle()) && this.isbn.equals(passedIn.getISBN()) && this.pages == passedIn.getBookPages();
        }
    }

    public Author[] getArrayAuthor(){
        return this.authors;
    }

    public Author getFirstAuthor(){
        return this.authors[0];
    }

    public String getISBN(){
        return this.isbn;
    }

    public int getBookPages(){
        return this.pages;
    }

    public String getBookTitle(){
        return this.title;
    }

    public Publisher getPublisher(){
        return this.pub;
    }

    public int hashCode(){
        return this.title.hashCode() + this.isbn.hashCode();
    }

    public void setISBN(String isbn){
        if(isbn != null && !isbn.isEmpty()) {
            this.isbn = isbn;
        } else {
            throw new IllegalArgumentException("Bad parameters.");
        }


    }

    public void setPages(int pages){
        if(pages < 1) {
            throw new IllegalArgumentException("Bad parameters.");
        }
            this.pages = pages;
    }

    public void setTitle(String title){
        if(title != null && !title.isBlank()) {
            this.title = title;
        } else {
            throw new IllegalArgumentException("Bad parameters.");
        }

    }

    public String toString(){
        return this.title + ", ISBN: " + this.isbn;
    }


}
