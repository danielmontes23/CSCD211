package cscd211comparators;

import cscd211classes.Book;
import java.util.Comparator;

public class FirstAuthorComparator implements Comparator<Book> {
    public FirstAuthorComparator(){

    }

    public int compare(final Book b1, final Book b2) {
        if (b1 == null || b2 == null) {
            throw new IllegalArgumentException("One or both books are null.");
        }
        return b1.getFirstAuthor().compareTo(b2.getFirstAuthor());
    }
}
