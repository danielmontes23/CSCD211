package cscd211tests;//THIS IS NOT THE TEST I WILL GRADE BY.  THIS IS JUST A SAMPLE TO HELP YOU GET STARTED.


import cscd211Inheritance.Accountant;
import cscd211Inheritance.Lawyer;
import cscd211Inheritance.Programmer;
import cscd211Lab7.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

import static org.junit.jupiter.api.Assertions.*;

public class BasicTestLab7 {
    private final PrintStream originalOut = System.out;
    private ByteArrayOutputStream testOut;


    @BeforeEach
    public void init() {
        testOut = new ByteArrayOutputStream();
        System.setOut(new PrintStream(testOut));
    }

    @AfterEach
    public void cleanUp() {
        System.setOut(originalOut);
    }

//THIS IS NOT THE TEST I WILL GRADE BY.  THIS IS JUST A SAMPLE TO HELP YOU GET STARTED.

    @Test
    public void testProgrammerToString() {
        Programmer p = new Programmer("Bob", 10, 10, true);
        assertEquals("Programmer: Bob", p.toString());
    }
//THIS IS NOT THE TEST I WILL GRADE BY.  THIS IS JUST A SAMPLE TO HELP YOU GET STARTED.

    @Test
    public void getTypeTest() {
        Programmer p = new Programmer("Bob", 10, 10, true);
        assertEquals("Programmer", p.getType());
    }
//THIS IS NOT THE TEST I WILL GRADE BY.  THIS IS JUST A SAMPLE TO HELP YOU GET STARTED.

    @Test
    public void programmerReportTest() {
        Programmer p = new Programmer("Bob", 10, 10, true);
        p.report();
        assertEquals("I am a Programmer.  I get 20.0,  and I get a bus pass.\n", testOut.toString().replaceAll("\r", ""));
    }
//THIS IS NOT THE TEST I WILL GRADE BY.  THIS IS JUST A SAMPLE TO HELP YOU GET STARTED.

    @Test
    public void lawyerReportTest() {
        Lawyer l = new Lawyer("Bob", 10, 10, 10);
        l.report();
        assertEquals("I am a lawyer.  I get 20.0,  and I have 10 shares of stock.\n", testOut.toString().replaceAll("\r", ""));
    }
//THIS IS NOT THE TEST I WILL GRADE BY.  THIS IS JUST A SAMPLE TO HELP YOU GET STARTED.

    @Test
    public void AccountantReportTest() {
        Accountant a = new Accountant("Bob", 10, 10, 10);
        a.report();
        assertEquals("I am an accountant.  I make 20.0 plus a parking allowance of 10.0\n", testOut.toString().replaceAll("\r", ""));
    }
//THIS IS NOT THE TEST I WILL GRADE BY.  THIS IS JUST A SAMPLE TO HELP YOU GET STARTED.

    @Test
    public void compareToTest() {
        Programmer p = new Programmer("Bob", 10, 10, true);
        Accountant p2 = new Accountant("Bob", 10, 10, 1.0);
        assertEquals(15, p.compareTo(p2));
    }
//THIS IS NOT THE TEST I WILL GRADE BY.  THIS IS JUST A SAMPLE TO HELP YOU GET STARTED.

    @Test
    public void compareToTest2() {
        Programmer p = new Programmer("Bob", 10, 10, true);
        Programmer p2 = new Programmer("Bob", 10, 20, true);
        assertEquals(1, p2.compareTo(p));
        assertEquals(-1, p.compareTo(p2));
    }
//THIS IS NOT THE TEST I WILL GRADE BY.  THIS IS JUST A SAMPLE TO HELP YOU GET STARTED.

    @Test
    public void compareToTest3() {
        Programmer p = new Programmer("Bob", 50, 10, true);
        Programmer p2 = new Programmer("Bob", 10, 10, true);
        assertEquals(1, p.compareTo(p2));
        assertEquals(-1, p2.compareTo(p));
    }
//THIS IS NOT THE TEST I WILL GRADE BY.  THIS IS JUST A SAMPLE TO HELP YOU GET STARTED.

    @Test
    public void main(){
        String test = "Employee List\n" +
            "Programmer: Mr. Ima Nerd\n" +
            "Programmer: Mrs. Ima Nerd\n" +
            "Accountant: Mr. Bean Counter\n" +
            "Accountant: Mrs. Bean Counter\n" +
            "Lawyer: Mr. Lawyer\n" +
            "Lawyer: Mrs. Lawyer\n" +
            "\n" +
            "Employee Salaries\n" +
            "Mr. Ima Nerd - 60000.0\n" +
            "Mrs. Ima Nerd - 65000.0\n" +
            "Mr. Bean Counter - 100000.0\n" +
            "Mrs. Bean Counter - 75000.0\n" +
            "Mr. Lawyer - 180000.0\n" +
            "Mrs. Lawyer - 190000.0\n" +
            "\n" +
            "Employee Report\n" +
            "I am a Programmer.  I get 60000.0,  and I get a bus pass.\n" +
            "I am a Programmer.  I get 65000.0,  and I do not get a bus pass.\n" +
            "I am an accountant.  I make 100000.0 plus a parking allowance of 50.0\n" +
            "I am an accountant.  I make 75000.0 plus a parking allowance of 150.0\n" +
            "I am a lawyer.  I get 180000.0,  and I have 25 shares of stock.\n" +
            "I am a lawyer.  I get 190000.0,  and I have 125 shares of stock.\n" +
            "\n" +
            "Employee List\n" +
            "Accountant - Mrs. Bean Counter - 75000.0\n" +
            "Accountant - Mr. Bean Counter - 100000.0\n" +
            "Lawyer - Mr. Lawyer - 180000.0\n" +
            "Lawyer - Mrs. Lawyer - 190000.0\n" +
            "Programmer - Mr. Ima Nerd - 60000.0\n" +
            "Programmer - Mrs. Ima Nerd - 65000.0\n\n";

        CSCD211Lab7.main(null);
        assertEquals(test, testOut.toString().replaceAll("\r",""));
    }
}
