package cscd211Inheritance;

public class Lawyer extends Employee{
    private int stockOptions;

    public Lawyer(final String name, final double basePayrate, final double additionalPayrate, final int stockOptions){
        super(name, basePayrate, additionalPayrate);

        if(stockOptions < 0 )
            throw new IllegalArgumentException("Stock options is less than 0.");

        this.stockOptions = stockOptions;
    }

    public int getStockOptions(){
        return this.stockOptions;
    }

    public void setStockOptions(final int stockOptions){
        if(stockOptions < 0 )
            throw new IllegalArgumentException("Stock options is less than 0.");

        this.stockOptions = stockOptions;
    }

    @Override
    public void report(){
        System.out.println("I am a lawyer." + "  I get " + getSalary() + ",  and I have " + getStockOptions() + " shares of stock.");
        //System.out.println("I am a lawyer. I get " + getSalary() + ", and I have 25 shares of stock.");
        //System.out.println("I am a lawyer. I get " + getSalary() + ", and I have 125 shares of stock.");
    }

    @Override
    public String toString(){
        String str ="";
        return str = "Lawyer: " + this.getName();
    }
}
