package cscd211Inheritance;

public abstract class Employee implements Comparable<Employee>{
    private final double BASE;

    private String name;

    private double salary;

    public Employee(final String name, final double basePayrate, final double additionalPayrate){
        //Exception needed
        if(name == null || name.isBlank() || basePayrate < 0 || additionalPayrate < 0)
            throw new IllegalArgumentException("Bad parameters.");

        this.name = name;
        this.BASE = basePayrate;
        this.salary = additionalPayrate + this.BASE;
    }

    public double getSalary(){
        return this.salary;
    }

    public String getName(){
        return this.name;
    }

    public String getType(){
        return this.getClass().getSimpleName();
    }

    public void setSalary(final double additionalPayrate){
        if(additionalPayrate < 0)
            throw new IllegalArgumentException("Additional pay rate is less than 0.");

        this.salary = additionalPayrate + this.BASE;
    }

    public void setName(final String name){
        if(name == null || name.isBlank())
            throw new IllegalArgumentException("Name is null or empty.");

        this.name = name;
    }

    @Override
    public String toString(){
        String str = " ";
        return str;
    }

    public int compareTo(final Employee another){
        if(another == null)
            throw new IllegalArgumentException("Another is null");


        int res = this.getType().compareTo(another.getType());
        if(res != 0)
            return res;

        res = Double.valueOf(this.salary).compareTo(Double.valueOf(another.salary));
        return res;
//        if(this == null)
//            throw new RuntimeException(" ");

//        int res = this.type.compareTo(another.type);
//        if(res != 0)
//            return res;
//
//        return Double.compare(this.weight, another.weight);
//        return Double.valueOf(this.weight).compareTo(Double.valueOf(another.weight));
    }

    public abstract void report();
}