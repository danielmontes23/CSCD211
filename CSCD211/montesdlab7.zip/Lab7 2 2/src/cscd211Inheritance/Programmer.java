package cscd211Inheritance;

public class Programmer extends Employee{
    private boolean busPass;

    public Programmer(final String name, final double basePayrate, final double additionalPayrate, final boolean busPass){
        super(name, basePayrate, additionalPayrate);
        this.busPass = busPass;
    }

    public boolean getBusPass(){

        return this.busPass;
    }

    public void setBusPass(boolean busPass){

        this.busPass = busPass;
    }

    @Override
    public void report(){
        if(busPass)
            System.out.println("I am a Programmer.  I get " + getSalary() + ",  and I get a bus pass.");
        else{
            System.out.println("I am a Programmer.  I get " + getSalary() + ",  and I do not get a bus pass.");
        }
    }

    @Override
    public String toString(){
        String str ="";
        return str = "Programmer: " + this.getName();
    }
}
