package cscd211Inheritance;

public class Accountant extends Employee{
    private double parkingStipend;

    public Accountant(String name, final double basePayrate, final double additionalPayrate, final double parkingStipend){
        super(name, basePayrate, additionalPayrate);

        if(parkingStipend < 1.00)
            throw new IllegalArgumentException("Parking stipend is less than 1.00.");

        //super(name, basePayrate, additionalPayrate);
        this.parkingStipend = parkingStipend;
    }

    public double getParkingStipend(){

        return parkingStipend;
    }

    public void setParkingStipend(final double parkingStipend){
        if(parkingStipend < 1)
            throw new IllegalArgumentException("Parking stipend is less than 1.");

        this.parkingStipend = parkingStipend;
    }

    @Override
    public void report(){
        System.out.println("I am an accountant. "+" I make " + getSalary() + " plus a parking allowance of "+ getParkingStipend());
    }

    @Override
    public String toString(){
        String str ="";
        return str = "Accountant: " + this.getName();
    }
}
