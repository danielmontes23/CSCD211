package lab8.cscd211inheritance;

public abstract class Employee implements Comparable<Employee>{

    private double BASE;
    private String name;

    protected double salary;

    /**
     *
     * @param name
     * @param basePayrate
     * @param additionalPayrate
     */
    public Employee(final String name, final double basePayrate, final double additionalPayrate){
        if(name == null || name.isBlank() || basePayrate < 0 || additionalPayrate < 0)
            throw new IllegalArgumentException("Bad Parameters. (Employee class)");

        this.name = name;
        this.BASE = basePayrate;
        this.salary = additionalPayrate + this.BASE;
    }

    /**
     *
     * @return
     */
    public double getSalary(){
        return salary;
    }

    /**
     *
     * @return
     */
    public double getBaseSalary(){
        return BASE;
    }

    /**
     *
     * @return
     */
    public String getName(){
        return name;
    }

    /**
     *
     * @return
     */
    public String getType(){
        return this.getClass().getSimpleName();
    }

    /**
     *
     * @return
     */
    @Override
    public String toString(){
        return name;
    }

    /**
     *
     * @param another the object to be compared.
     * @return
     */
    public int compareTo(final Employee another){
        if(another == null)
            throw new IllegalArgumentException("Another is null");


        int res = this.getType().compareTo(another.getType());
        if(res != 0)
            return res;

        res = Double.valueOf(this.salary).compareTo(Double.valueOf(another.salary));
        return res;
    }

    /**
     *
     */
    public abstract void report();
}

