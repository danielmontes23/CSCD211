package lab8.cscd211inheritance;

public class Lawyer extends Employee{

    private int stockOptions;

    /**
     *
     * @param name
     * @param basePayrate
     * @param additionalPayrate
     * @param stockOptions
     */
    public Lawyer(final String name, final double basePayrate, final double additionalPayrate, final int stockOptions){
        super(name, basePayrate, additionalPayrate);

        if(stockOptions < 0)
            throw new IllegalArgumentException("Stock options are less than 0.");

        this.stockOptions = stockOptions;
    }

    /**
     *
     * @return
     */
    public int getStockOptions(){
        return stockOptions;
    }

    /**
     *
     */
    public void report(){
        System.out.println("I am a lawyer." + " I get " + getSalary() + ", and I have " + getStockOptions() + " shares of stock.");
    }

    /**
     *
     * @return
     */
    public String toString(){
        return "Lawyer: " + this.getName();
    }
}
