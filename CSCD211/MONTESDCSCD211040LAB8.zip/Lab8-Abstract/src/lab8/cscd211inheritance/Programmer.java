package lab8.cscd211inheritance;

public class Programmer extends Employee{

    private boolean busPass;

    /**
     *
     * @param name
     * @param basePayrate
     * @param additionalPayrate
     * @param busPass
     */
    public Programmer(final String name, final double basePayrate, final double additionalPayrate, final boolean busPass){
        super(name, basePayrate, additionalPayrate);
        this.busPass = busPass;
    }

    /**
     *
     * @return
     */
    public boolean getBusPass(){
        return busPass;
    }

    /**
     *
     */
    public void report(){
        if(busPass)
            System.out.println("I am a Programmer. I get " + getSalary() + ", and I get a bus pass.");
        else{
            System.out.println("I am a Programmer. I get " + getSalary() + ", and I do not get a bus pass.");
        }
    }

    /**
     *
     * @return
     */
    public String toString(){
        return "Programmer: " + this.getName();
    }
}
