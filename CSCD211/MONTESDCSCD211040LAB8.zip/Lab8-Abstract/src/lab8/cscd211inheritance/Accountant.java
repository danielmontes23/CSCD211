package lab8.cscd211inheritance;

public class Accountant extends Employee{

    private double parkingStipend;

    /**
     *
     * @param name
     * @param basePayrate
     * @param additionalPayrate
     * @param parkingStipend
     */
    public Accountant(final String name, final double basePayrate, final double additionalPayrate, final double parkingStipend){
        super(name, basePayrate, additionalPayrate);

        if(parkingStipend < 0.00)
            throw new IllegalArgumentException("Parking stipend is less than 0.00.");

        this.parkingStipend = parkingStipend;
    }

    /**
     *
     * @return
     */
    public double getParkingStipend(){
        return getParkingStipend();
    }

    /**
     *
     */
    @Override
    public void report(){
        System.out.println("I am an accountant. I make " + getBaseSalary() + " plus a parking stipend of " + parkingStipend);
    }

    /**
     *
     * @return
     */
    @Override
    public String toString(){
        return "Accountant: " + this.getName();
    }
}
