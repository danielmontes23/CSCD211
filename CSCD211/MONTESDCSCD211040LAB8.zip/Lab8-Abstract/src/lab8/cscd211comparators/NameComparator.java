package lab8.cscd211comparators;

import lab8.cscd211inheritance.Employee;
import java.util.Comparator;

public class NameComparator implements Comparator<Employee> {

    /**
     *
     * @param e1 the first object to be compared.
     * @param e2 the second object to be compared.
     * @return
     */
    public int compare(Employee e1, Employee e2){
        if(e1 == null || e2 == null)
            throw new IllegalArgumentException("Employee 1 or 2 is null.");

        return e1.getName().compareTo(e2.getName());
    }
}
