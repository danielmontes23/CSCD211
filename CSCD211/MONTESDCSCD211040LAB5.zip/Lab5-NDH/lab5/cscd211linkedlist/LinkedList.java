package lab5.cscd211linkedlist;

import java.util.*;


/**
 * The LinkedList class and Node class.  All parameters will be passed as final.
 *
 * @param <T> A type that implements Comparable and a compareTo method using the Generic
 * @NOTE T item is just a different word for data
 */
public class LinkedList<T extends Comparable <? super T>>
{

    private static class Node<T>
   {
      public T data;
      public Node next;
      
      public Node()
      {
          this.data = null;
          this.next = null;
      }
      
      public Node(final T data)
      {
         this(data, null);
      }
      
      public Node(final T data, final Node next)
      {
         this.data = data;
         this.next = next;
      }
   }// end class Node
   
   private Node head;
   private int size;
   
   /**
    * Constructs a list with no dummy head node containing the elements of the 
    * specified array, that are in the order the array.
    * 
    * @param array Representing the T array
    *
    * @throws IllegalArgumentException if the array is null
    */
   public LinkedList(final T [] array)
   {
       if(array == null)
           throw new IllegalArgumentException("Bad parameter. ");

       this.head = new Node(null, null);
       this.size = 0;
       for(int x = 0; x < array.length; x++){
           this.add(array[x]);
       }
   }// end EVC
   

   /**
    * Inserts the specified element at the beginning of this list.
    *
    * @param item The item to add
    *
    * @throws IllegalArgumentException if item is null
    */
   public void addFirst(final T item)
   {
        if(item == null)
            throw new IllegalArgumentException("Bad parameter.");

        Node nn = new Node(item);
        nn.next = this.head.next;
        this.head.next = nn;
        this.size++;
   }// end addFirst
   
 
   /**
    * Appends the specified element to the end of this list.
    *
    * @param item The element to be appended to this list
    *
    * @throws IllegalArgumentException if item is null
    */
   public void add(final T item)
   {
        if(item == null)
            throw new IllegalArgumentException("Bad parameter.");

        if(size == 0) {

            Node<T> cur = new Node<>(item);
            cur.next = this.head;
            this.head = cur;
            this.size++;
        }else{
            Node<T> cur = this.head;
            while(cur.next != null){
                cur = cur.next;
            }
            cur.next = new Node<>(item);
            size++;
        }
   }// end add
   
   /**
    * Inserts all of the elements in the specified array into this list, 
    * starting at the specified position. Shifts the element currently at that position 
    * (if any) and any subsequent elements to the right (increases their indices). 
    * The new elements will appear in the list in the order that they were in the array
    *
    * @param index at which to insert the first element from the specified array
    * @param array containing elements to be added to this list
    *
    * @throws IllegalArgumentException if the array is null
    * @throws IndexOutOfBoundsException if index less than 0 or greater than size
    */
   public void addAll(final int index, final T [] array)
   {
       if(array == null)
           throw new IllegalArgumentException("Bad parameter.");
       if(index < 0 || index > this.size)
           throw new IndexOutOfBoundsException("Out of bounds.");

       Node<T> cur = this.head;
       for(int i = 0; i < index; i++){
           cur = cur.next;
       }
       Node<T> list = cur.next;
       for(int i = 0; i < array.length; i++){
           Node<T> nn = new Node<>(array[i]);
           cur.next = nn;
           cur = cur.next;
           size++;
       }
       cur.next = list;
   }// end addAll
   
   /**
    * Removes all of the elements from this list. 
    * The list will be empty after this call returns.    
    */
   public void clear()
   {
       this.head = head;
       this.size = 0;
   }// end clear
   
   /**
    * Returns the element at the specified position in this list.
    *
    * @param index The index of the element to return
    * @return T The element at the specified position in this list
    *
    * @throws IndexOutOfBoundsException if index is less than 0 or greater than or equal to size
    */
   public T get(final int index)
   {
       if(index < 0 || index >= this.size)
           throw new IndexOutOfBoundsException("Out of bounds.");

       Node cur = this.head.next;
       int count = 0;
       while(cur != null && count != index){
           cur = cur.next;
           count++;
       }
       return (T) cur.data;
   }// end get
   
   /**
    * Returns the last element in this list.
    *
    * @return The last element in the list
    *
    * @throws NoSuchElementException if the list is empty
    */
   public T getLast()
   {
       if(this.size == 0)
           throw new NoSuchElementException("Empty list.");

       Node cur = this.head.next;
       while(cur.next != null){
           cur = cur.next;
       }
       return (T) cur.data;
   }// end getLast
   
   /**
    * Retrieves and removes the head (first element) of this list.
    *
    * @return The head element in the list
    *
    * @throws NoSuchElementException if the list is empty
    */
   public T remove()
   {
       if(this.size == 0)
           throw new NoSuchElementException("Empty list.");

       T removedValue = (T) this.head.data;
       this.head = this.head.next;
       this.size--;

       return removedValue;

       //Node cur = this.head.next;
       //this.head.next = cur.next;
       //this.size--;

       //return (T) cur.data;
   }// end remove
   

   
   /**
    * Returns true if all occurrences of data are removed from the list or false otherwise
    *
    * @param data The value for all occurrences to be removed from the list
    * @return boolean Representing if the list was modified or not
    *
    * @throws IllegalArgumentException if data is null
    */
   public boolean removeAllOccurrences(final T data)
   {
       if(data == null)
           throw new IllegalArgumentException("Bad parameter.");

       boolean modified = false;

       if(this.size == 0){
           return false;
       }

       Node<T> cur = this.head;
       Node<T> prev = null;
       while(cur.next != null){
           if(cur.data.equals(data)){ //Data is found
               if(prev != null){ //Mid list
                   prev.next = cur.next; //Skipping the current node(detach from list)
               }else{
                   this.head = cur.next; //Detaching head
               }
               this.size--;
               modified = true;
           }else{ //The data is not found in the current node
               prev = cur;
           }
           cur = cur.next; //Move to the next node, whether or not the data is found in the current node
       }
       if(cur.data.equals(data)){
           if(prev != null){
               prev.next = null;
           }else{
               this.head = null;
           }
           this.size--;
           modified = true;
       }
       return modified;
   }// end removeAllOccurrences


    /**
     * Removes and returns the last element from this list.
     *
     * @return T the last element from the list
     *
     * @throws NoSuchElementException if this list is empty
     */
    public T removeLast() {
        if(this.size == 0)
            throw new NoSuchElementException("Empty list.");

        Node cur = this.head;
        Node prev = null;
        while(cur.next != null){
            prev = cur;
            cur = cur.next;
        }
        if(prev != null)
            prev.next = null;
        else
            this.head = null;
        this.size--;
        return (T) cur.data;
    }// end removeLast

    /**
     * Removes the element at the specified position in this list.
     * Shifts any subsequent elements to the left (subtracts one from their indices).
     * Returns the element that was removed from the list.
     *
     * @param index the index of the element to be removed
     * @return T The element previously at the specified position
     *
     * @throws IndexOutOfBoundsException if index is less than 0 or greater than or equal to size
     */
    public T remove(int index) {
        if(index < 0 || index >= this.size)
            throw new IndexOutOfBoundsException("Out of bounds.");

        if(index == 0)
            return this.remove();

        else if(index == this.size - 1)
            return this.remove();

        else{
            Node prev = null;
            Node cur = this.head;
            for(int i = 1; i <= index; i++){
                prev = cur;
                cur = cur.next;
            }

            T nodeData = (T) cur.data;
            prev.next = cur.next;
            size--;
            return nodeData;
        }
        //Node cur = this.head.next;
        //this.head.next = cur.next;
        //this.size--;

        //return (T) cur.data;
    }// end remove
 
   
   
   /**
    * Returns the number of elements in this list.
    *
    * @return int The size
    */
   public int size()
   {
      return this.size;
   }// end size
   
   
   /**
    * Returns an array containing all of the elements in this list in proper 
    * sequence (from first to last element).
    *
    * <br> The returned array will be "safe" in that no references to it are maintained
    * by this list. (In other words, this method must allocate a new array). 
    * The caller is thus free to modify the returned array.
    *
    * @return Object [] an array containing all of the elements in this list in proper sequence 
    */
   public Object [] toArray()
   {
      Object[] res = new Object[this.size];

      Node<T> cur = this.head;

      for(int i = 0; i < this.size; i++){
          res[i] = cur.data;
          cur = cur.next;
      }
      return res;
   }  // end toArray
   
   
   /**
    * Returns the contents of the list in the format [item, item, item]
    * or Empty List if the list is empty
    *
    * @return String Representing the contents of the list
    */
   public String toString()
   {
       String str ="";
       Node cur = this.head.next;
       if ( size ==0)
           return "Empty List";

       while (cur!= null){

           if ( cur.next ==null)
               str += cur.data;
           else {
               str += cur.data+ ", ";
           }
           cur = cur.next;
       }

       return  "[" + str +"]";
   }// end toString
}// end list