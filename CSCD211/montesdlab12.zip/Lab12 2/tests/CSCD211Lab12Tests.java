import org.junit.jupiter.api.*;

import static org.junit.jupiter.api.Assertions.*;
import cscd211recursion.LinkedList;

import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.util.Random;

public class CSCD211Lab12Tests {
    public  final PrintStream ORIGINALOUT = System.out;
    public  ByteArrayOutputStream testOut;


    @BeforeEach
    public  void init() {
        testOut = new ByteArrayOutputStream();
        System.setOut(new PrintStream(testOut));
    }


    @AfterEach
    public  void cleanUp() {
        System.setOut(ORIGINALOUT);

    }
    @Test
    public void recurssiveLinkedListTest() {
        LinkedList myList = new LinkedList();

        for(int x = 10; x > 0; x--)
            myList.addFirst(Integer.valueOf(x));
        myList.recursiveSubList(0,4);

        assertEquals("5 4 3 2 1 ", testOut.toString().replaceAll("\r", ""));
    }

    @Test
    public void secondhalfRecussiveLinkedListTest() {
        LinkedList myList = new LinkedList();

        for(int x = 10; x > 0; x--)
            myList.addFirst(Integer.valueOf(x));
        myList.recursiveSubList(5,9);

        assertEquals("10 9 8 7 6 ", testOut.toString().replaceAll("\r", ""));
    }
    @RepeatedTest(value = 500)
    public void randomSizeLinkedListTest() {
        Random random = new Random();
        Random random2 = new Random();
        Random random3 = new Random();
        LinkedList myList = new LinkedList();
        int size = random.nextInt(20,75);
        for(int x = 0; x < size; x++) {
            int add = random.nextInt(1, 1000);
            myList.addFirst(add);
        }
        int start;
        start = random2.nextInt(1, myList.getSize()-10);
        int end;
        end = random3.nextInt(start, myList.getSize());
        String test = "";
        int count = 0;
        for(String x : myList) {
            if(count >= start && count <= end)
                test = x + test;
            count++;
        }


        myList.recursiveSubList(start, end);

        assertEquals(test, testOut.toString().replaceAll("\r", ""));
    }
    @Test
    public void indexZeroTest() {
        LinkedList myList = new LinkedList();
        myList.addFirst(1);
        myList.addFirst(1);
        myList.recursiveSubList(0,0);
        assertEquals("1 ", testOut.toString().replaceAll("\r", ""));
    }

    @Test
    public void endIndexTest() {
        LinkedList myList = new LinkedList();
        myList.addFirst(1);
        myList.addFirst(1);
        myList.recursiveSubList(1,1);
        assertEquals("1 ", testOut.toString().replaceAll("\r", ""));
    }

    @Test
    public void emptyListTest() {
        LinkedList myList = new LinkedList();
        myList.recursiveSubList(0, 0);
        assertEquals("The list is empty", testOut.toString().replaceAll("\r", ""));
    }

    @Test
    public void indexOutOfBoundsIllegalArgumentTest() {
        LinkedList myList = new LinkedList();
        myList.addFirst(1);
        myList.addFirst(1);
        assertThrows(IllegalArgumentException.class, () -> myList.recursiveSubList(-1, 1));
    }

    @Test
    public void indexOutOfBounds2IllegalArgumentTest() {
        LinkedList myList = new LinkedList();
        myList.addFirst(1);
        myList.addFirst(1);
        assertThrows(IllegalArgumentException.class, () -> myList.recursiveSubList(1, 3));
    }
}
