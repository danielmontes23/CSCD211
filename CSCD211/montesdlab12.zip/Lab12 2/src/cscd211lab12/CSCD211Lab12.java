package cscd211lab12;

import cscd211recursion.LinkedList;

public class CSCD211Lab12
{
    public static void main(final String [] args)
    {
        LinkedList myList = new LinkedList();

        for(int x = 10; x > 0; x--)
            myList.addFirst(Integer.valueOf(x));

        System.out.println(myList);

        myList.recursiveSubList(0, 4);
        System.out.println();
        myList.recursiveSubList(5, 9);
        System.out.println();
    }// end main
}
