package cscd211recursion;

import java.util.Iterator;

public class LinkedList implements Iterable<String> {
    private class Node {
        public Node next;
        public Comparable data;

        public Node() {
        }

        public Node(Comparable data) {
            this(data, null);
        }

        public Node(Comparable data, Node next) {
            this.data = data;
            this.next = next;
        }
    }//end nested Node class

    private Node head;
    private int size;

    public LinkedList() {
        this.head = new Node(); // Dummy Head Node
        this.size = 0;
    }//end constructor

    public void addFirst(final Comparable data) {
        this.head.next = new Node(data, this.head.next);
        this.size++;
    }

    public int getSize() {
        return this.size;
    }

    public String toString() {
        if (this.head.next == null)
            return "Empty List";

        else {
            String str = "";
            Node cur = this.head.next;

            while (cur != null) {
                str += cur.data + " ";
                cur = cur.next;
            }

            return str;
        }// end else
    }// end toString

    @Override
    public Iterator<String> iterator() {
        return new LinkedListIterator();
    }

    private class LinkedListIterator implements Iterator<String> {
        private Node curr;

        public LinkedListIterator() {
            this.curr = head.next;
        }

        @Override
        public boolean hasNext() {
            return this.curr != null;
        }

        @Override
        public String next() {
            String res = this.curr.data.toString() + " ";
            this.curr = this.curr.next;
            return res;
        }
    }

    /**
     * Write the subListReverse method. This method is part of the LinkedList class above.
     * This method should print the contents of the list stopIndex to startIndex (inclusive) in REVERSE order.
     * A private helper stubbed out method that you must use is provided.
     * - If the list is empty, print the message "The list is empty"
     * - otherwise print the nodes stopIndex to startIndex in reverse order
     *
     * @param stopIndex  The index to stop printing the list in reverse
     * @param startIndex The index to start printing the list in reverse
     * @throws IllegalArgumentException if stopIndex is less than 0, start index is greater than or equal to size,
     *                                  stop index is less than start index
     */
    public void recursiveSubList(int stopIndex, int startIndex) {
        if(this.head.next==null)
            System.out.print("The list is empty");
        else if (stopIndex < 0|| startIndex>=this.size)
            throw new IllegalArgumentException("Invalid indices");

        else {
            recursiveSublist(stopIndex, startIndex, 0, this.head.next);
        }
    }

    private void recursiveSublist(int stopIndex, int startIndex, int index, Node cur) {
        if (index == startIndex)
            System.out.print(cur.data + " ");
        else {
            recursiveSublist(stopIndex, startIndex, index + 1, cur.next);

            if (index >= stopIndex) {

                System.out.print(cur.data + " ");
            }
        }
    }
}