package cscd211LinkedList;

import java.util.NoSuchElementException;

    public class LinkedList<T extends Comparable<? super T>> {
        private class Node {
            public T data;
            public Node next;

            public Node(final T data) {
                this.data = data;
                this.next = null;
            }

            public Node(final T data, final Node next) {
                this.data = data;
                this.next = next;
            }
        }

        private Node head;
        private int size;

        public LinkedList(final T[] array) {
            if (array == null)
                throw new NullPointerException("Array is null.");

            this.head = new Node(null, null);
            this.size = 0;
            for (int x = 0; x < array.length; x++) {
                this.add(array[x]);
                //this.size++;
            }
        }

        public int size() {
            return this.size;
        }

        public void clear() {
            this.head = head;
            this.size = 0;
        }

        public void addFirst(final T item) {
            if (item == null)
                throw new NullPointerException("Item is null.");

            Node nn = new Node(item);
            nn.next = this.head.next;
            this.head.next = nn;
            this.size++;
        }

        public T removeLast() {
            if (this.size == 0)
                throw new NoSuchElementException("Empty List");

            Node cur = this.head, prev = null;
            while (cur.next != null) {
                prev = cur;
                cur = cur.next;
            }
            if (prev != null)
                prev.next = null;
            else
                this.head = null;
            this.size--;
            return (T) cur.data;
        }

        public boolean remove(final T item) {
            if (item == null)
                throw new IllegalArgumentException("Data is null.");

            if (this.head == null)
                return false;

            if (this.head.data != null && this.head.data.equals(item)) {
                this.head = this.head.next;
                size--;
                return true;
            }

            Node cur = this.head.next, prev = this.head;
            while (cur != null) {
                if (cur.data != null && cur.data.equals(item)) {
                    prev.next = cur.next;
                    size--;
                    return true;
                }
                prev = cur;
                cur = cur.next;
            }
            return false;
        }

        public String toString() {
            String str ="";
            Node cur = this.head.next;
            if ( size ==0)
                return "Empty List";

            while (cur!= null){

                if ( cur.next ==null)
                    str += cur.data;
                else {
                    str += cur.data+ ", ";
                }
                cur = cur.next;
            }

            return  "[" +str +"]";
        }

        public boolean add(final T item) {
            if (item == null)
                throw new NullPointerException("Item is null.");

            Node nn = new Node(item);
            if(this.head == null) {
                this.head = nn;
                this.size++;
            } else {
                Node cur = this.head;
                while (cur.next != null) {
                    cur = cur.next;
                }
                cur.next = nn;
                this.size++;
            }
            return true;
        }

        public boolean addAll(final int index, final T[] array) {
            if (array == null)
                throw new NullPointerException("Array is null.");
            if (index < 0 || index > this.size)
                throw new IndexOutOfBoundsException("Out of bounds.");

            if (array.length == 0)
                return false;

            if (index == 0) {
                Node cur = this.head;
                Node prev = null;
                for (int x = 0; x < array.length; x++) {
                    Node nn = new Node(array[x], cur);
                    if (x == 0) {
                        this.head.next = nn;
                    } else {
                        prev.next = nn;
                    }
                    prev = nn;
                    this.size++;
                }
            } else {
                Node cur = this.head.next, prev = null;
                for (int x = 0; x < index; x++) {
                    prev = cur;
                    cur = cur.next;
                }
                for (int x = 0; x < array.length; x++) {
                    Node nn = new Node(array[x], cur);
                    prev.next = nn;
                    prev = nn;
                    cur = nn.next;
                    this.size++;
                }
            }
            return true;
        }

        public T get(final int index) {
            if (index < 0 || index >= size())
                throw new IndexOutOfBoundsException("Out of bounds.");

            Node cur = this.head.next;
            int count = 0;

            while (cur != null && count != index) {
                cur = cur.next;
                count++;
            }
            return (T)cur.data;
        }


        public T getLast() {
            if (this.size == 0)
                throw new NoSuchElementException("Empty list");

            Node cur = this.head.next;
            while (cur.next != null) {
                cur = cur.next;
            }
            return cur.data;
        }
//            Node nn = new Node(this.head.data, this.head.next);
//            Node cur = this.head, prev = null;
//            if (this.head.next.data == null) {
//                return nn.data;
//            }
//            while (cur != null) {
//                prev = cur;
//                cur = cur.next;
//            }
//            Node Nn1 = new Node(prev.data, prev.next);
//            return Nn1.data;
//        }

        public T remove() {
            if (this.size == 0)
                throw new NoSuchElementException("Empty list");

            Node cur = this.head.next;
            this.head.next = cur.next;
            this.size--;
            return cur.data;
        }

        public Object[] toArray() {
            Object[] res = new Object[this.size];

            Node cur = this.head.next;
            int i = 0;
            while (cur != null) {
                res[i] = cur.data;
                cur = cur.next;
                i++;
            }
            return res;
        }
    }
