import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import cscd211LinkedList.LinkedList;
import java.util.NoSuchElementException;

import static org.junit.jupiter.api.Assertions.*;

public class LinkedListTest {
    @Nested
    class ConstructorTest {
        @Test
        public void LinkedListIntegerArrayConstructorTest() {
            Integer[] array = {1, 2, 3, 4, 5};
            LinkedList<Integer> list = new LinkedList<>(array);
            assertEquals(5, list.size());
            assertEquals(1, list.get(0));
            assertEquals(2, list.get(1));
            assertEquals(3, list.get(2));
            assertEquals(4, list.get(3));
            assertEquals(5, list.get(4));
        }

        @Test
        public void LinkedListStringArrayConstructorTest() {
            String[] array = {"a", "b", "c", "d", "e"};
            LinkedList<String> list = new LinkedList<>(array);
            assertEquals(5, list.size());
            assertEquals("a", list.get(0));
            assertEquals("b", list.get(1));
            assertEquals("c", list.get(2));
            assertEquals("d", list.get(3));
            assertEquals("e", list.get(4));
        }

        @Test
        public void LinkedListEmptyArrayConstructorTest() {
            Integer[] array = {};
            LinkedList<Integer> list = new LinkedList<>(array);
            assertEquals(0, list.size());
            assertEquals("Empty List", list.toString());
        }

        @Test
        public void LinkedListExceptionTest() {
            assertThrows(NullPointerException.class, () -> new LinkedList<>(null));
        }

    }

    @Nested
    class SizeAndClear{
        @Test
        public void sizeTest(){
            Integer[] array = {1, 2, 3, 4, 5};
            LinkedList<Integer> list = new LinkedList<>(array);
            assertEquals(5, list.size());
        }

        @Test
        public void clearTest(){
            Integer[] array = {1, 2, 3, 4, 5};
            LinkedList<Integer> list = new LinkedList<>(array);
            list.clear();
            assertEquals(0, list.size());
        }

        @Test
        public void clearTestToString(){
            Integer[] array = {1, 2, 3, 4, 5};
            LinkedList<Integer> list = new LinkedList<>(array);
            list.clear();
            assertEquals("Empty List", list.toString());
        }
    }

    @Nested
    class AddFirst{
        @Test
        public void addFirstTest(){
            Integer[] array = {1, 2, 3, 4, 5};
            LinkedList<Integer> list = new LinkedList<>(array);
            list.addFirst(0);
            assertEquals(6, list.size());
            assertEquals(0, list.get(0));

        }

        @Test
        public void addFirstTestToString(){
            Integer[] array = {1, 2, 3, 4, 5};
            LinkedList<Integer> list = new LinkedList<>(array);
            list.addFirst(0);
            assertEquals("[0, 1, 2, 3, 4, 5]", list.toString());
        }

        @Test
        public void addFirstStringLLTestGet(){
            String[] array = {"a", "b", "c", "d", "e"};
            LinkedList<String> list = new LinkedList<>(array);
            list.addFirst("f");
            assertEquals(6, list.size());
            assertEquals("f", list.get(0));
        }

        @Test
        public void addFirstExceptionTest(){
            Integer[] array = {1, 2, 3, 4, 5};
            LinkedList<Integer> list = new LinkedList<>(array);
            assertThrows(NullPointerException.class, () -> list.addFirst(null));
        }

    }

    @Nested
    class RemoveLast{
        @Test
        public void removeLastTest(){
            Integer[] array = {1, 2, 3, 4, 5};
            LinkedList<Integer> list = new LinkedList<>(array);
            list.removeLast();
            assertEquals(4, list.size());
            assertEquals(4, list.get(3));
        }

        @Test
        public void removeLastTestToString(){
            Integer[] array = {1, 2, 3, 4, 5};
            LinkedList<Integer> list = new LinkedList<>(array);
            list.removeLast();
            assertEquals("[1, 2, 3, 4]", list.toString());
        }

        @Test
        public void removeLastStringLLTestGet(){
            String[] array = {"a", "b", "c", "d", "e"};
            LinkedList<String> list = new LinkedList<>(array);
            list.removeLast();
            assertEquals(4, list.size());
            assertEquals("d", list.get(3));
        }
        @Test
        public void removeLastOneItemList(){
            Integer[] array = {1};
            LinkedList<Integer> list = new LinkedList<>(array);
            list.removeLast();
            assertEquals(0, list.size());
            assertEquals("Empty List", list.toString());
        }

        @Test
        public void removeLastExceptionTest(){
            Integer[] array = {};
            LinkedList<Integer> list = new LinkedList<>(array);
            assertThrows(NoSuchElementException.class, () -> list.removeLast());
        }

        @Test
        public void removeLastDataTest(){
            Integer[] array = {1, 2, 3, 4, 5};
            LinkedList<Integer> list = new LinkedList<>(array);
            assertEquals(5, list.removeLast());
            assertEquals(4, list.size());
            assertEquals(4, list.get(3));
        }

    }

    @Nested
    class RemoveItem{
        @Test
        public void removeTest(){
            Integer[] array = {1, 2, 3, 4, 5};
            LinkedList<Integer> list = new LinkedList<>(array);
            list.remove(2);
            assertEquals(4, list.size());
            assertEquals(3, list.get(1));
        }

        @Test
        public void removeTestBooleanCheck(){
            Integer[] array = {1, 2, 3, 4, 5};
            LinkedList<Integer> list = new LinkedList<>(array);
            assertTrue(list.remove(2));
        }

        @Test
        public void removeTestBooleanCheckFalse(){
            Integer[] array = {1, 2, 3, 4, 5};
            LinkedList<Integer> list = new LinkedList<>(array);
            assertFalse(list.remove(6));
        }

        @Test
        public void removeTestToStringCheck(){
            Integer[] array = {1, 2, 3, 4, 5};
            LinkedList<Integer> list = new LinkedList<>(array);
            list.remove(2);
            assertEquals("[1, 3, 4, 5]", list.toString());
        }

        @Test
        public void removeFirstTest(){
            Integer[] array = {1, 2, 3, 4, 5};
            LinkedList<Integer> list = new LinkedList<>(array);
            list.remove(1);
            assertEquals(4, list.size());
            assertEquals(2, list.get(0));
        }

        @Test
        public void removeLastToStringTest(){
            Integer[] array = {1, 2, 3, 4, 5};
            LinkedList<Integer> list = new LinkedList<>(array);
            list.remove(5);
            assertEquals("[1, 2, 3, 4]", list.toString());
        }

        @Test
        public void removeExceptionTestItemNull(){
            Integer[] array = {1, 2, 3, 4, 5};
            LinkedList<Integer> list = new LinkedList<>(array);
            assertThrows(IllegalArgumentException.class, () -> list.remove(null));
        }

    }

    @Nested
    class ToString{
        @Test
        public void toStringTest(){
            Integer[] array = {1, 2, 3, 4, 5};
            LinkedList<Integer> list = new LinkedList<>(array);

            assertEquals("[1, 2, 3, 4, 5]", list.toString());
        }

        @Test
        public void toStringTestEmptyList(){
            Integer[] array = {};
            LinkedList<Integer> list = new LinkedList<>(array);

            assertEquals("Empty List", list.toString());
        }

        @Test
        public void toStringTestStringLL(){
            String[] array = {"a", "b", "c", "d", "e"};
            LinkedList<String> list = new LinkedList<>(array);

            assertEquals("[a, b, c, d, e]", list.toString());
        }

        @Test
        public void doubleToStringOneItemTest(){
            Double[] array = {1.0};
            LinkedList<Double> list = new LinkedList<>(array);

            assertEquals("[1.0]", list.toString());
        }

    }

    @Nested
    class Add{
        @Test
        public void addTest(){
            Integer[] array = {1, 2, 3, 4, 5};
            LinkedList<Integer> list = new LinkedList<>(array);

            list.add(2);
            assertEquals(6, list.size());
            assertEquals(2, list.get(5));
        }

        @Test
        public void stringAddTestBooleanCheck(){
            String[] array = {"a", "b", "c", "d", "e"};
            LinkedList<String> list = new LinkedList<>(array);

            assertTrue(list.add("f"));
        }

        @Test
        public void doubleAddTestToStringCheck(){
            Double[] array = {1.0, 2.0, 3.0, 4.0, 5.0};
            LinkedList<Double> list = new LinkedList<>(array);

            list.add(6.0);
            assertEquals("[1.0, 2.0, 3.0, 4.0, 5.0, 6.0]", list.toString());
        }

        @Test
        public void emptyListAddTest(){
            Integer[] array = {};
            LinkedList<Integer> list = new LinkedList<>(array);

            list.add(1);
            assertEquals(1, list.size());
            assertEquals(1, list.get(0));
        }
        @Test
        public void oneItemAddTest(){
            Integer[] array = {1};
            LinkedList<Integer> list = new LinkedList<>(array);

            list.add(2);
            assertEquals(2, list.size());
            assertEquals(2, list.get(1));
        }
        @Test
        public void AddExceptionTestItemNull(){
            Integer[] array = {1, 2, 3, 4, 5};
            LinkedList<Integer> list = new LinkedList<>(array);
            assertThrows(NullPointerException.class, () -> list.add(null));
        }
    }

    @Nested
    class AddAll{
        @Test
        public void addAllTestEmptyList(){
            Integer[] array = {};
            LinkedList<Integer> list = new LinkedList<>(array);

            Integer[] array2 = {1, 2, 3, 4, 5};

            list.addAll(0,array2);
            assertEquals(5, list.size());
            assertEquals(5, list.get(4));
        }

        @Test public void addAllTestOneItem(){
            Integer[] array = {1};
            LinkedList<Integer> list = new LinkedList<>(array);

            Integer[] array2 = {2, 3, 4, 5};

            list.addAll(0,array2);
            assertEquals(5, list.size());
            assertEquals(1, list.get(4));
        }

        @Test
        public void addAllTestOneItemEndStart(){
            Integer[] array = {1};
            LinkedList<Integer> list = new LinkedList<>(array);

            Integer[] array2 = {2, 3, 4, 5};

            list.addAll(1,array2);
            assertEquals(5, list.size());
            assertEquals(5, list.get(4));
        }

        @Test
        public void addAllTestMultipleItemMiddleToString(){
            Integer[] array = {1, 2, 3, 4, 5};
            LinkedList<Integer> list = new LinkedList<>(array);

            Integer[] array2 = {6, 7, 8, 9, 10};

            list.addAll(2,array2);
            assertEquals("[1, 2, 6, 7, 8, 9, 10, 3, 4, 5]", list.toString());
        }

        @Test
        public void addAllTestMultipleItemEndToString(){
            Integer[] array = {1, 2, 3, 4, 5};
            LinkedList<Integer> list = new LinkedList<>(array);

            Integer[] array2 = {6, 7, 8, 9, 10};

            list.addAll(5,array2);
            assertEquals("[1, 2, 3, 4, 5, 6, 7, 8, 9, 10]", list.toString());
        }

        @Test
        public void addAllArrayNullPointerExceptionTest(){
            Integer[] array = {1, 2, 3, 4, 5};
            LinkedList<Integer> list = new LinkedList<>(array);
            assertThrows(NullPointerException.class, () -> list.addAll(0, null));
        }

        @Test
        public void addAllIndexOutOfBoundsExceptionTest(){
            Integer[] array = {1, 2, 3, 4, 5};
            LinkedList<Integer> list = new LinkedList<>(array);
            Integer[] array2 = {6, 7, 8, 9, 10};
            assertThrows(IndexOutOfBoundsException.class, () -> list.addAll(6, array2));
        }

        @Test
        public void addAllIndexOutOfBoundsExceptionTest2(){
            Integer[] array = {1, 2, 3, 4, 5};
            LinkedList<Integer> list = new LinkedList<>(array);
            Integer[] array2 = {6, 7, 8, 9, 10};
            assertThrows(IndexOutOfBoundsException.class, () -> list.addAll(-1, array2));
        }

    }
    @Nested
    class GetAndGetLast{

        @Test
        public void getTest(){
            Integer[] array = {1, 2, 3, 4, 5};
            LinkedList<Integer> list = new LinkedList<>(array);
            assertEquals(3, list.get(2));
        }

        @Test
        public void getLastTest(){
            Integer[] array = {1, 2, 3, 4, 5};
            LinkedList<Integer> list = new LinkedList<>(array);
            assertEquals(5, list.getLast());
        }

        @Test
        public void getLastTestOneItem(){
            Integer[] array = {1};
            LinkedList<Integer> list = new LinkedList<>(array);
            assertEquals(1, list.getLast());
        }

        @Test
        public void getAtFirstIndexTest(){
            Integer[] array = {1, 2, 3, 4, 5};
            LinkedList<Integer> list = new LinkedList<>(array);
            assertEquals(1, list.get(0));
        }

        @Test
        public void getAtLastIndexTest(){
            Integer[] array = {1, 2, 3, 4, 5};
            LinkedList<Integer> list = new LinkedList<>(array);
            assertEquals(5, list.get(4));
        }

        @Test
        public void getAtNegativeIndexTest(){
            Integer[] array = {1, 2, 3, 4, 5};
            LinkedList<Integer> list = new LinkedList<>(array);
            assertThrows(IndexOutOfBoundsException.class, () -> list.get(-1));
        }

        @Test
        public void getAtIndexOutOfBoundsTest(){
            Integer[] array = {1, 2, 3, 4, 5};
            LinkedList<Integer> list = new LinkedList<>(array);
            assertThrows(IndexOutOfBoundsException.class, () -> list.get(5));
        }

        @Test
        public void getLastEmptyListTest(){
            Integer[] array = {};
            LinkedList<Integer> list = new LinkedList<>(array);
            assertThrows(NoSuchElementException.class, () -> list.getLast());
        }

    }
    @Nested
    class ToArray{

        @Test
        public void integerArrayToArrayTestSizeThree(){
            Integer[] array = {1, 2, 3};
            LinkedList<Integer> list = new LinkedList<>(array);
            Object [] array2 = list.toArray();
            assertEquals(3, array2.length);
            assertEquals(1, (Integer) array2[0]);
            assertEquals(2, (Integer) array2[1]);
            assertEquals(3, (Integer) array2[2]);
        }

        @Test
        public void stringArrayToArrayTestSizeThree(){
            String[] array = {"1", "2", "3"};
            LinkedList<String> list = new LinkedList<>(array);
            Object [] array2 = list.toArray();
            assertEquals(3, array2.length);
            assertEquals("1", (String) array2[0]);
            assertEquals("2", (String) array2[1]);
            assertEquals("3", (String) array2[2]);
        }

        @Test
        public void stringDragonBallZToArrayTestSize10(){
            String[] array = {"Goku", "Vegeta", "Gohan", "Trunks", "Goten", "Piccolo", "Krillin", "Yamcha", "Tien", "Chiaotzu"};
            LinkedList<String> list = new LinkedList<>(array);
            Object [] array2 = list.toArray();
            assertEquals(10, array2.length);
            assertEquals("Goku", (String) array2[0]);
            assertEquals("Vegeta", (String) array2[1]);
            assertEquals("Gohan", (String) array2[2]);
            assertEquals("Trunks", (String) array2[3]);
            assertEquals("Goten", (String) array2[4]);
            assertEquals("Piccolo", (String) array2[5]);
            assertEquals("Krillin", (String) array2[6]);
            assertEquals("Yamcha", (String) array2[7]);
            assertEquals("Tien", (String) array2[8]);
            assertEquals("Chiaotzu", (String) array2[9]);
        }

        @Test
        public void stringOnePieceLuffytoArraySizeOne(){
            String[] array = {"Luffy"};
            LinkedList<String> list = new LinkedList<>(array);
            Object [] array2 = list.toArray();
            assertEquals(1, array2.length);
            assertEquals("Luffy", (String) array2[0]);
        }

        @Test
        public void emptyListToArrayTest(){
            Integer[] array = {};
            LinkedList<Integer> list = new LinkedList<>(array);
            Object [] array2 = list.toArray();
            assertEquals(0, array2.length);
        }
    }
}
