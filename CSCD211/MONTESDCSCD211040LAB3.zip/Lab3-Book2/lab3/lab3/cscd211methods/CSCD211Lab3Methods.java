package lab3.cscd211methods;

import lab3.cscd211classes.Author;
import lab3.cscd211classes.Book;
import lab3.cscd211classes.Publisher;
import lab3.cscd211enums.Genre;
import java.io.PrintStream;
import java.util.Scanner;

public class CSCD211Lab3Methods {

    public static Book[] addBook(final Book[] array, final Book book){
        if(array == null || book == null)
            throw new IllegalArgumentException("Bad parameters.");

        Book[] newArray = new Book[array.length + 1];

        for(int i = 0; i < array.length; i++){
            newArray[i] = array[i];
        }

        newArray[array.length] = book;
        return newArray;
    }

    public static Book createBook(final Scanner kb){
        if(kb == null)
            throw new IllegalArgumentException("Scanner is null.");

        System.out.print("Enter a Title: ");
        String title = kb.nextLine();
        System.out.print("Enter a ISBN: ");
        String isbn = kb.nextLine();
        System.out.print("Enter a Genre: ");
        String type = kb.nextLine();
        System.out.print("Enter the Publisher's name: ");
        String pubName = kb.nextLine();
        System.out.print("Enter the Publisher's city: ");
        String pubCity = kb.nextLine();
        System.out.println("Author's first name: ");
        String first = kb.nextLine();
        System.out.println("Author's last name: ");
        String last = kb.nextLine();

        Author author = new Author(first, last);

        System.out.print("Enter the number of pages : ");
        int pages = kb.nextInt();

        Author[] array = new Author[1];
        array[0] = author;

        Book book = new Book(title, isbn, pages , type, pubName, pubCity, array);
        kb.nextLine();

        return book;
    }

    public static Genre getGenre(final String g){
        if(g == null || g.isEmpty())
            throw new IllegalArgumentException("Bad parameters.");

        return Genre.valueOf(g);
    }

    public static Book[] fillArray(final Scanner fin){
        if(fin == null)
            throw new IllegalArgumentException("Bad parameters.");

        int numOfBooks = fin.nextInt();
        fin.nextLine();
        Book[] books = new Book[numOfBooks];

        for(int i = 0; i < numOfBooks; i++){

                String title = fin.nextLine();
                String isbn = fin.nextLine();
                String page = fin.nextLine();
                int pages = Integer.parseInt(page);
                String type = fin.nextLine();
                String pub = fin.nextLine();
                String pubCity = fin.nextLine();
                Publisher pubs = new Publisher(pub, pubCity);
                String numOfAuthor = fin.nextLine();
                int numOfAuthors = Integer.parseInt(numOfAuthor);
                //fin.nextLine();
                Author[] authors = new Author[numOfAuthors];
                String authorFirst;
                String authorLast;
                for(int d = 0; d < numOfAuthors; d++){
                    String[] info = fin.nextLine().split(" ");
                    authorFirst = info[0];
                    authorLast = info[1];
                    authors[d] = new Author(authorFirst, authorLast);
                }
                books[i] = new Book(title, isbn, pages, type, pub, pubCity, authors);
            }
        return books;
    }

    public static int menu(final Scanner kb){
        if(kb == null)
            throw new IllegalArgumentException("Bad scanner menu");

        int choice;
        do
        {
            System.out.println("Please choose from the following");
            System.out.println("1. Print the books to the screen.");
            System.out.println("2. Print the books to a file.");
            System.out.println("3. Sort the book using compareTo.");
            System.out.println("4. Sort the books by first author as a Comparator.");
            System.out.println("5. Add a book.");
            System.out.println("6. Quit.");
            System.out.print("Choice --> ");
            choice = Integer.parseInt(kb.nextLine());
            System.out.println();
        }while(choice < 1 || choice > 6);
            return choice;
    }

    public static void printBooks(final Book[] array, final PrintStream fout) {
        if (array == null || fout == null)
            throw new IllegalArgumentException("Bad parameters.");


        for(int i = 0; i < array.length; i++){
            fout.println(array[i] + "\n");
        }
    }

    public static String readFileName(final Scanner kb) {
        if (kb == null)
            throw new IllegalArgumentException("Bad parameters.");

        System.out.println("Enter an output file name: ");
        String fileName = kb.nextLine().trim();

        return fileName;
    }
}
