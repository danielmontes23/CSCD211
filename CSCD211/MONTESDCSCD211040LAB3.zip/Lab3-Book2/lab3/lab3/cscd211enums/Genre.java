package lab3.cscd211enums;

import java.io.Serializable;

public enum Genre implements Comparable<Genre>, Serializable {
    EDUCATION(15, "education"),
    FICTION(10, "fiction"),
    NONFICTION(20, "non-fiction"),
    ROMANCE(5, "romance"),
    SCIFI(30, "sci-fi");

    private final String name;
    private final int value;

    private Genre(int value, String name){
        this.value = value;
        this.name = name;
    }


    public String getName() {
        return name;
    }

    @Override
    public String toString() {
        return this.name();
    }
}

