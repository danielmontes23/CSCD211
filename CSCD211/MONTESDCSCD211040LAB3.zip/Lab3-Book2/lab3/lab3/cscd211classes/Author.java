package lab3.cscd211classes;

public class Author implements Comparable<Author>{
    private final String first;
    private final String last;

    public Author(final String first, final String last){
        if(first == null || last == null)
            throw new IllegalArgumentException("Strings are null.");
        if(first.isEmpty() || last.isEmpty())
            throw new IllegalArgumentException("Strings are empty");

        this.first = first;
        this.last = last;
    }

    public int compareTo(final Author pi){
        if(pi == null)
            throw new IllegalArgumentException("PI is null.");

        if(this.last.compareTo(pi.last) == 0){
            if(this.first.compareTo(pi.first) == 0){
                return this.first.compareTo(pi.first);
            }
            return this.first.compareTo(pi.first);
        }
        return this.last.compareTo(pi.last);
    }

    public String getFirstName(){
        return first;
    }

    public String getLastName(){
        return last;
    }

    @Override
    public String toString(){
        return this.last + " " + this.first;
    }
}


