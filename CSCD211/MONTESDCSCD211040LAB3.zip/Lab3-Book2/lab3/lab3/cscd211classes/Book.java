package lab3.cscd211classes;


import lab3.cscd211enums.Genre;
import java.util.Objects;

public class Book implements Comparable<Book>{

    private Author[] authors;
    private String isbn;
    private int pages;
    private Publisher pub;
    private String title;
    private Genre type; //Make final before turning in


    public Book(final String title, final String isbn, final int pages, final Genre type, final Publisher pubs, final String[] author){
        this.title = title;
        this.isbn = isbn;
        this.pages = pages;
        this.type = type;
        this.pub = new Publisher(pubs.getPubName(), pubs.getPubCity());

        Author[] authors = new Author[author.length];

        for(int i = 0; i < author.length; i++){
            String[] info = author[i].split(",");
            String first = info[0];
            String last = info[1];

            authors[i] = new Author(first, last);
        }
        this.authors = authors;
    }


    public Book(final String title, final String isbn, final int pages, final String type, final String pubName, final String pubCity, final Author[] array){
        if (title != null && !title.isBlank() && isbn != null && !isbn.isBlank() && pages >= 1 && pubName != null && pubName.isBlank() && pubCity != null && !pubCity.isBlank() && array != null)
            throw new IllegalArgumentException("Bad parameters.");

        this.title = title;
        this.isbn = isbn;
        this.pages = pages;
        this.pub = new Publisher(pubName, pubCity);
        this.authors = new Author[array.length];
    }


    public int compareTo(final Book passedIn){
        if(this.pub.compareTo(passedIn.pub) == 0){
            if(this.title.compareTo(passedIn.title) == 0){
                return this.isbn.compareTo(passedIn.isbn);
            }
            return this.title.compareTo(passedIn.title);
        }
        return this.pub.compareTo(passedIn.pub);
    }

    @Override
    public boolean equals(final Object obj){ //Code needs to be changed
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof Book)) {
            return true;
        }
        Book anotherBook = (Book)obj;
        if(this.title.equals(anotherBook.title)){
            if(this.isbn.equals(anotherBook.isbn)){
                if(this.pages == anotherBook.pages);
                return true;
            }
            return false;
        }
        return false;
        //return Objects.equals(city, publisher.city) && Objects.equals(name, publisher.name);
    }


    public Author getFirstAuthor(){
        return this.authors[0];
    }


    public String getISBN(){
        return isbn;
    }


    public int getPages(){
        return pages;
    }


    public String getTitle(){
        return title;
    }


    public Genre getType(){
        return type;
    }

    @Override
    public int hashCode(){
        return (this.title.hashCode() + this.isbn.hashCode());
    }


    public void setISBN(final String isbn){
        if(isbn == null)
            throw new IllegalArgumentException("ISBN is null.");
        if(isbn.isEmpty())
            throw new IllegalArgumentException("String is empty.");

        this.isbn = isbn;
    }


    public void setPages(final int pages){
        if(pages <= 0)
            throw new IllegalArgumentException("Pages is less than or equal to 0.");

        this.pages = pages;
    }


    public void setTitle(final String title){
        if(title == null)
            throw new IllegalArgumentException("Title is null.");
        if(title.isEmpty())
            throw new IllegalArgumentException("String is empty.");

        this.title = title;
    }


    @Override
    public String toString(){ //Double check toString
        return this.title + ", " + this.isbn + ": " + hashCode();
    }
}
