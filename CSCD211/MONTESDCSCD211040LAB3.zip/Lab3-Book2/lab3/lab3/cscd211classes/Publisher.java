package lab3.cscd211classes;

public class Publisher implements Comparable<Publisher>{

    private final String city;
    private final String name;

    public Publisher(String name, String city){
        if(name == null || city == null)
            throw new IllegalArgumentException("Bad Parameters.");
        if(name.isEmpty() || city.isEmpty())
            throw new IllegalArgumentException("Bad Parameters.");

        this.city = city;
        this.name = name;
    }

    public int compareTo(Publisher pi){
        if(pi == null)
            throw new IllegalArgumentException("Bad Parameters.");

        return this.name.compareTo(this.name);
        //return this.name.compareTo(another.name);
    }

    public String getPubName(){
        return this.getPubName();
    }

    public String getPubCity(){
        return this.getPubCity();
    }

    @Override
    public String toString(){
        return this.name + ", " + this.city;
    }
}

