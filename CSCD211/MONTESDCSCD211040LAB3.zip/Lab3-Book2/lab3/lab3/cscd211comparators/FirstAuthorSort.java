package lab3.cscd211comparators;

import lab3.cscd211classes.Book;
import java.util.Comparator;

public class FirstAuthorSort implements Comparator<Book> {

    public int compare(final Book b1, final Book b2){
        if(b1 == null || b2 == null)
            throw new IllegalArgumentException("Bad parameters.");

        return b1.getFirstAuthor().compareTo(b2.getFirstAuthor());
    }
}
